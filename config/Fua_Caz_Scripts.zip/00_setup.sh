#!/bin/bash
#SBATCH --job-name=setup_conf_figs
#SBATCH --time=00:10:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --output=/dev/null

set -euo pipefail

# ============================================================================
# CONFERENCE FIGURES PIPELINE: Setup & Sample Manifest
# ============================================================================
# Purpose: Initialize directory structure, create barlist.tsv for all 12 isolates
# Usage: bash 00_setup.sh
# ============================================================================

# Define root directory (adjust if needed)
export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"

# Create analysis subdirectories
mkdir -p "${ANALYSIS_ROOT}"/{00_input,01_genome_stats,02_accessory_genome,03_synteny,04_effector_analysis,05_cazyme,06_phenotype,07_correlation,08_figures,logs}

cat > "${ANALYSIS_ROOT}/00_input/README.md" << 'EOF'
# Conference Figures: Data Directory Structure

## Expected Input Layout (Symlink or Copy Here)
```
${ANALYSIS_ROOT}/00_input/
├── genomes/                    # Symlink to FASTA assemblies
│   ├── isolate1.fasta
│   ├── isolate2.fasta
│   └── ... (12 total)
├── annotations/                # GBK or GFF files
│   ├── isolate1.gbk (or .gff3)
│   └── ...
├── proteomes/                  # Protein FASTA (one per isolate)
│   ├── isolate1.faa
│   └── ...
├── effectors/                  # Effector FASTA (one per isolate or combined)
│   ├── isolate1_effectors.fasta
│   └── ...
├── growth_rate_heat_cold.csv   # Phenotype: heat/cold stress
├── growth_rate_optimum.csv     # Phenotype: optimum temperature (7 days)
└── barley_pathogenicity.csv    # Raw pathogenicity assay data
```

## barlist.tsv Format (auto-generated below)
Tab-separated: sample, species, strain, isolate
EOF

# ============================================================================
# AUTO-GENERATE SAMPLE MANIFEST (Edit isolate names/species as needed)
# ============================================================================
# Instructions: Replace placeholder isolate names and species below.
# Species should be one of: F. graminearum, F. cerealis, F. proliferatum, 
#                           F. fujikuroi, F. subglutinans, etc.

cat > "${ANALYSIS_ROOT}/barlist.tsv" << 'EOF'
sample	species	strain	isolate
Isolate_001	F. graminearum	NA	FUS001
Isolate_002	F. graminearum	NA	FUS002
Isolate_003	F. cerealis	NA	FUS003
Isolate_004	F. cerealis	NA	FUS004
Isolate_005	F. proliferatum	NA	FUS005
Isolate_006	F. proliferatum	NA	FUS006
Isolate_007	F. fujikuroi	NA	FUS007
Isolate_008	F. fujikuroi	NA	FUS008
Isolate_009	F. subglutinans	NA	FUS009
Isolate_010	F. subglutinans	NA	FUS010
Isolate_011	F. graminearum	NA	FUS011
Isolate_012	F. cerealis	NA	FUS012
EOF

echo "✓ Created directory structure in: ${ANALYSIS_ROOT}"
echo "✓ Generated barlist.tsv (12 isolates)"
echo ""
echo "NEXT STEPS:"
echo "1. Edit ${ANALYSIS_ROOT}/barlist.tsv with actual isolate names and species"
echo "2. Symlink or copy your genomes/ annotations/ proteomes/ effectors/ to 00_input/"
echo "3. Place growth_rate_heat_cold.csv, growth_rate_optimum.csv, barley_pathogenicity.csv in 00_input/"
echo "4. Run: bash 01_genome_stats.sh"
echo ""
echo "Pipeline structure:"
echo "  01_genome_stats.sh          → structural variation overview (4a)"
echo "  02_accessory_genome.sh      → macro-structural variation (4b)"
echo "  03_synteny.sh               → lineage-specific fissions (4c)"
echo "  04_effector_analysis.sh     → effector expansions (4d)"
echo "  05_cazyme_annotation.sh     → CAzyme profiles"
echo "  06_phenotype_parsing.sh     → growth rates & pathogenicity (1, 2, 3)"
echo "  07_correlation_analysis.sh  → CAzymes vs virulence"
echo "  08_generate_figures.py      → publication-ready plots"

exit 0
