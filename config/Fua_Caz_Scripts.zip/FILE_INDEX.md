# Conference Figure Pipeline – Complete File Index

**Generated:** July 4, 2026  
**For:** Dr. Max Chi (USDA-ARS DFRC, Madison)  
**Project:** Fusarium Integrative Genomics – Heat/Cold Stress & Barley Pathogenicity

---

## 📋 Documentation Files (Start Here)

### **QUICK_START.md** ⭐ **← START HERE**
- **5-minute setup guide** for running the entire pipeline
- Step-by-step instructions (5 steps)
- Troubleshooting tips
- Performance benchmarks
- What each script does (one-paragraph summaries)
- **Read this first!**

### **README_PIPELINE.md** (Comprehensive)
- Full technical documentation (800+ lines)
- Detailed script descriptions
- Tool requirements & Ceres module loading
- Output file explanations
- Figure interpretation guide
- Advanced customization options

### **INPUT_DATA_FORMATS.md** (Data Specification)
- Exact CSV format specifications for all 3 phenotype files
- FASTA/GBK/GFF3 requirements
- barlist.tsv structure (12 isolates)
- Data validation checklist
- Common errors & fixes
- Directory structure diagram
- **Read this when preparing data!**

### **FILE_INDEX.md** (This File)
- Overview of all 12 files in the package
- File sizes & purposes
- Quick reference guide

---

## 🔧 Pipeline Scripts (8 SLURM-Ready Bash Scripts)

### **00_setup.sh** (3.9 KB)
**Purpose:** Initialize directory structure  
**Time:** 10 min | **CPU:** 1 | **RAM:** 2 GB  
**Inputs:** None (creates directories)  
**Outputs:** 
- Empty directory tree (01–08 subdirectories)
- Blank `barlist.tsv` (you must edit with actual isolates)
- `00_input/README.md` (data placement guide)

**Usage:**
```bash
bash 00_setup.sh
```

---

### **01_genome_stats.sh** (4.0 KB)
**Purpose:** Extract structural variation metrics from FASTA assemblies  
**Time:** 30 min | **CPU:** 4 | **RAM:** 8 GB  
**Inputs:** 
- 12× `genomes/{sample}.fasta`
- `barlist.tsv`
**Outputs:**
- `genome_stats_summary.tsv` → **Fig 4a**

**Metrics extracted:**
- Genome size (bp)
- GC content (%)
- Scaffold/contig count
- N50 value
- Repeat content (from GFF if available)

---

### **02_accessory_genome.sh** (6.8 KB)
**Purpose:** Identify core vs. accessory genes via presence/absence analysis  
**Time:** 1 h | **CPU:** 8 | **RAM:** 16 GB  
**Inputs:**
- 12× `annotations/{sample}.gbk` (or .gff3)
- `barlist.tsv`
**Outputs:**
- `gene_presence_absence.tsv` (binary matrix: 1/0)
- `gene_presence_absence_classified.tsv` (with core/accessory label)
- `accessory_summary.tsv` → **Fig 4b**

**Classification:**
- **Core genes:** present in ≥11/12 isolates
- **Accessory genes:** present in <11/12 isolates

---

### **03_synteny.sh** (7.2 KB)
**Purpose:** Detect chromosomal fusions/fissions via pairwise genome alignment  
**Time:** **4 h** | **CPU:** 16 | **RAM:** 32 GB  
**Tools:** minimap2 (asm5 mode)  
**Inputs:**
- 12× `genomes/{sample}.fasta`
- `barlist.tsv`
**Outputs:**
- `paf/`: raw minimap2 alignments
- `synteny_pairwise.tsv` (per-pair stats)
- `fusions/lineage_specific_breakpoints.bed`
- `fusions/lineage_specific_fissions.tsv` → **Fig 4c**

**Key metric:** Synteny breaks (rearrangements > 10 kb gaps)

---

### **04_effector_analysis.sh** (7.8 KB)
**Purpose:** Count effector proteins per isolate, identify expansions  
**Time:** 1.5 h | **CPU:** 8 | **RAM:** 16 GB  
**Optional tool:** CD-HIT (if available, for clustering)  
**Inputs:**
- 12× `effectors/{sample}_effectors.fasta`
- `genome_stats_summary.tsv` (for normalization)
- `barlist.tsv`
**Outputs:**
- `effector_counts.tsv`
- `effector_families.tsv` (if cd-hit available)
- `effector_expansion_summary.tsv`
- `effector_diversity.tsv` → **Fig 4d**

**Metrics:**
- Total effectors per isolate
- Effectors/Mb (normalized)
- Expansion index (max/min)
- Shannon & Simpson diversity

---

### **05_cazyme_annotation.sh** (7.6 KB)
**Purpose:** Annotate carbohydrate-active enzymes (CAzymes) using dbCAN  
**Time:** **6 h** | **CPU:** 16 | **RAM:** 32 GB  
**Tools:** dbCAN (module or conda)  
**Inputs:**
- 12× `proteomes/{sample}.faa`
- `barlist.tsv`
**Outputs:**
- `raw_output/`: per-isolate dbCAN logs
- `cazyme_summary.tsv`
- `parsed/cazyme_profiles.tsv`
- `cazyme_diversity.tsv` → **Fig 5 (left panels)**

**CAzyme families:**
- GH (Glycoside Hydrolases)
- GT (Glycosyltransferases)
- PL (Polysaccharide Lyases)
- CE (Carbohydrate Esterases)

---

### **06_phenotype_parsing.sh** (8.0 KB)
**Purpose:** Parse growth rate & pathogenicity CSV files, compute statistics  
**Time:** 30 min | **CPU:** 4 | **RAM:** 8 GB  
**Inputs:**
- `growth_rate_heat_cold.csv` (long format)
- `growth_rate_optimum.csv` (7-day diameter)
- `barley_pathogenicity.csv` (raw assay data)
- `barlist.tsv`
**Outputs:**
- `growth_rates_summary.tsv` → **Fig 1 & 2**
- `growth_rates_optimum_summary.tsv` → **Fig 3**
- `pathogenicity_summary.tsv` → **Fig 4**
- `merged_phenotypes.tsv` (all in one table)

**Statistics computed:** mean, SD, SEM, severity classification

---

### **07_correlation_analysis.sh** (7.9 KB)
**Purpose:** Test associations between CAzymes and virulence  
**Time:** 1 h | **CPU:** 4 | **RAM:** 8 GB  
**Tools:** Python (scipy, pandas)  
**Inputs:**
- `cazyme_summary.tsv`
- `pathogenicity_summary.tsv`
**Outputs:**
- `correlation_data.tsv` (merged table)
- `correlation_matrix.tsv` (Pearson & Spearman r)
- `correlation_pvalues.tsv` (p-values)
- `correlation_summary.tsv` (significant associations, p < 0.05)
- `species_cazyme_virulence.tsv` → **Fig 5 (right panels)**

**Tests:** Total CAzymes, GH, GT, PL, CE vs. virulence score

---

## 🎨 Visualization Script (Python)

### **08_generate_figures.py** (21 KB)
**Purpose:** Create all 9 publication-ready figures from TSV outputs  
**Time:** 5 min | **CPU:** 1 | **RAM:** 2 GB  
**Tools:** Python (matplotlib, seaborn, pandas)  
**Inputs:**
- All TSV files from scripts 01–07
**Outputs:**
```
08_figures/
├── Fig1_Heat_Stress.png
├── Fig2_Cold_Stress.png
├── Fig3_Optimum_Growth.png
├── Fig4_Barley_Pathogenicity.png
├── Fig4a_Structural_Variation.png
├── Fig4b_Accessory_Genes.png
├── Fig4c_Chromosomal_Fissions.png
├── Fig4d_Effector_Expansions.png
└── Fig5_CAzyme_Virulence.png
```

**Usage:**
```bash
python3 08_generate_figures.py /path/to/conference_figs
```

**Figure specs:**
- 300 DPI (publication-quality)
- Professional seaborn styling
- All labels, titles, error bars formatted
- Color-coded by species or severity
- PNG format (editable in PowerPoint/Illustrator)

---

## 📊 Output Data Files (Examples)

All analysis scripts produce TSV (tab-separated) or CSV files suitable for:
- Import into R/Python for further analysis
- Publication as supplementary tables
- Re-analysis or alternative visualizations

**Key outputs:**
- `genome_stats_summary.tsv` (genome metrics)
- `gene_presence_absence.tsv` (binary gene matrix)
- `effector_counts.tsv` (virulence factor inventory)
- `cazyme_summary.tsv` (CAzyme profiles)
- `pathogenicity_summary.tsv` (virulence scores)
- `correlation_summary.tsv` (statistical associations)

---

## 🚀 Quick Reference: File Summary

| File | Type | Size | Purpose | Dependencies |
|------|------|------|---------|--------------|
| **00_setup.sh** | Bash | 3.9 KB | Initialize directories | None |
| **01_genome_stats.sh** | Bash | 4.0 KB | Genome metrics | None |
| **02_accessory_genome.sh** | Bash | 6.8 KB | Gene presence/absence | GBK/GFF3 |
| **03_synteny.sh** | Bash | 7.2 KB | Chromosomal rearrangements | minimap2 |
| **04_effector_analysis.sh** | Bash | 7.8 KB | Effector inventories | cd-hit (opt) |
| **05_cazyme_annotation.sh** | Bash | 7.6 KB | CAzyme annotation | dbCAN |
| **06_phenotype_parsing.sh** | Bash | 8.0 KB | Parse CSV phenotypes | None |
| **07_correlation_analysis.sh** | Bash | 7.9 KB | CAzyme-virulence correlation | Python/scipy |
| **08_generate_figures.py** | Python | 21 KB | Create 9 figures | matplotlib/seaborn |
| **README_PIPELINE.md** | Markdown | 12 KB | Full documentation | – |
| **QUICK_START.md** | Markdown | 12 KB | 5-minute setup guide | – |
| **INPUT_DATA_FORMATS.md** | Markdown | 12 KB | CSV/FASTA specifications | – |
| **FILE_INDEX.md** | Markdown | This file | File listing & overview | – |

**Total pipeline:** ~10 KB of code + 36 KB documentation

---

## 📂 Directory Tree After Setup

```
/90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs/
├── 00_input/                    ← Place your raw data here
│   ├── genomes/
│   ├── annotations/
│   ├── proteomes/
│   ├── effectors/
│   ├── *.csv
│   └── README.md
├── 01_genome_stats/             ← Script 01 outputs
├── 02_accessory_genome/         ← Script 02 outputs
├── 03_synteny/                  ← Script 03 outputs
├── 04_effector_analysis/        ← Script 04 outputs
├── 05_cazyme/                   ← Script 05 outputs
├── 06_phenotype/                ← Script 06 outputs
├── 07_correlation/              ← Script 07 outputs
├── 08_figures/                  ← Script 08 outputs ← FINAL FIGURES!
├── logs/                        ← All script logs
└── barlist.tsv                  ← Sample manifest (you edit this)
```

---

## ⚙️ How to Use These Files

### **Step 1: Read Documentation**
1. Read **QUICK_START.md** (5 min)
2. Read **INPUT_DATA_FORMATS.md** (10 min) while preparing data
3. Skim **README_PIPELINE.md** (reference as needed)

### **Step 2: Prepare Data**
1. Copy this folder to Ceres: `/90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs`
2. Run `bash 00_setup.sh`
3. Edit `barlist.tsv` with your 12 isolate names & species
4. Place your genomes, annotations, proteomes, effectors, and CSVs in `00_input/`

### **Step 3: Run Pipeline**
```bash
sbatch 01_genome_stats.sh
sbatch 02_accessory_genome.sh
sbatch 03_synteny.sh
sbatch 04_effector_analysis.sh
sbatch 05_cazyme_annotation.sh
sbatch 06_phenotype_parsing.sh
sbatch 07_correlation_analysis.sh
# Wait for all to finish...
python3 08_generate_figures.py $(pwd)
```

### **Step 4: Collect Figures**
All PNG files ready in `08_figures/` → download to your computer → use in PowerPoint!

---

## 🔗 Workflow Diagram

```
00_setup.sh
    ↓
Input Data (00_input/)
    ↓
    ├─→ 01_genome_stats.sh          ────┐
    ├─→ 02_accessory_genome.sh      ────┤
    ├─→ 03_synteny.sh               ────┤
    ├─→ 04_effector_analysis.sh     ────┼─→ 08_generate_figures.py
    ├─→ 05_cazyme_annotation.sh     ────┤
    ├─→ 06_phenotype_parsing.sh     ────┤
    └─→ 07_correlation_analysis.sh  ────┘
                                          ↓
                                    08_figures/ (PNG files)
```

All scripts are **independent** (except 00_setup which runs first).  
Run **01–07 in parallel**, then run **08** once all complete.

---

## 🎯 Expected Outputs Summary

| Script | Main Output | Size | Figure |
|--------|------------|------|--------|
| 01 | genome_stats_summary.tsv | ~2 KB | Fig 4a |
| 02 | gene_presence_absence.tsv | ~500 KB | Fig 4b |
| 03 | synteny_pairwise.tsv | ~10 KB | Fig 4c |
| 04 | effector_counts.tsv | ~1 KB | Fig 4d |
| 05 | cazyme_summary.tsv | ~1 KB | Fig 5 |
| 06 | pathogenicity_summary.tsv | ~2 KB | Fig 4 |
| 07 | correlation_summary.tsv | ~5 KB | Fig 5 |
| 08 | 9× PNG files | ~2 MB total | All |

---

## 🐛 Troubleshooting Quick Links

| Issue | Read |
|-------|------|
| Setup errors | QUICK_START.md → Troubleshooting |
| Data format questions | INPUT_DATA_FORMATS.md |
| What does script X do? | README_PIPELINE.md → Script Descriptions |
| Figure interpretation | README_PIPELINE.md → Output Interpretation |
| Tool not found | QUICK_START.md → Performance Notes |

---

## 📞 Support

All scripts include:
- Inline comments explaining key decisions
- Error logging to `logs/` directory
- Fallback mechanisms (graceful degradation if optional tools unavailable)
- Detailed README for each output directory

For issues:
1. Check script logs: `tail logs/*.log`
2. Re-read relevant documentation section
3. Test with single isolate (edit barlist.tsv to 2 rows)

---

## 📝 Citation

If you publish work using this pipeline, cite:

**Tools:**
- minimap2: Li et al. 2018 (Bioinformatics)
- dbCAN: Zhang et al. 2018 (NAR)
- seaborn/matplotlib: Waskom 2021, Hunter et al.

**Resources:**
- SCINet Ceres/Atlas HPC
- USDA-ARS computational support

---

## ✅ Checklist Before Running

- [ ] Copied all 12 files to Ceres
- [ ] Created `/conference_figs` directory
- [ ] Edited `barlist.tsv` with actual isolate names
- [ ] Placed 12 genomes in `00_input/genomes/`
- [ ] Placed 12 annotations in `00_input/annotations/`
- [ ] Placed 12 proteomes in `00_input/proteomes/`
- [ ] Placed 12 effector files in `00_input/effectors/`
- [ ] Placed 3 CSV files in `00_input/`
- [ ] Modules available: minimap2, dbcan, miniconda
- [ ] Ready to sbatch!

---

**Good luck with your conference presentation!** 🍄🧬📊

---

**Version:** 1.0  
**Date:** July 4, 2026  
**Status:** Production-Ready
