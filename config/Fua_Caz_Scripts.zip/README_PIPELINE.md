# Conference Figures Pipeline: Full Fusarium Integrative Genomics Analysis

This pipeline generates publication-ready figures integrating genomic, proteomic, and phenotypic data from 12 Fusarium isolates under stress and pathogenicity conditions.

---

## Overview

**Output Figures:**
1. **Fig 1** – Heat Stress Growth
2. **Fig 2** – Cold Stress Growth  
3. **Fig 3** – Optimum Temperature Growth (7-day diameter)
4. **Fig 4** – Barley Seedling Pathogenicity
5. **Fig 4a** – Structural Variation Overview (genome stats)
6. **Fig 4b** – Macro-structural & Accessory Gene Variation
7. **Fig 4c** – Lineage-specific Chromosomal Fissions (synteny)
8. **Fig 4d** – Effector Gene Expansions
9. **Fig 5** – CAzyme Profiles & Correlation with Virulence

---

## Directory Structure

```
/90daydata/silage_microbiome/max.chi/MSA_2026/
└── conference_figs/
    ├── 00_input/                    # Place your raw data here
    │   ├── genomes/                 # FASTA assemblies (symlink or copy)
    │   ├── annotations/             # GBK or GFF files
    │   ├── proteomes/               # Protein FASTA (one per isolate)
    │   ├── effectors/               # Effector FASTA files
    │   ├── growth_rate_heat_cold.csv
    │   ├── growth_rate_optimum.csv
    │   └── barley_pathogenicity.csv
    ├── 01_genome_stats/
    ├── 02_accessory_genome/
    ├── 03_synteny/
    ├── 04_effector_analysis/
    ├── 05_cazyme/
    ├── 06_phenotype/
    ├── 07_correlation/
    ├── 08_figures/                  # Final publication-ready plots
    ├── logs/
    └── barlist.tsv                  # Sample manifest (auto-generated)
```

---

## Quick Start

### 1. **Setup**

```bash
cd /home/claude
bash 00_setup.sh
```

This creates the directory structure and generates `barlist.tsv`. **You must then:**

- Edit `barlist.tsv` with your actual isolate names and species assignments
- Copy or symlink your raw data to `00_input/` subdirectories

**barlist.tsv format** (tab-separated):
```
sample          species         strain  isolate
Isolate_001     F. graminearum  NA      FUS001
Isolate_002     F. graminearum  NA      FUS002
...
```

### 2. **Input Data Preparation**

Place your files in `/90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs/00_input/`:

**Genomes:**
```
genomes/
├── Isolate_001.fasta
├── Isolate_002.fasta
└── ... (12 total)
```

**Annotations:**
```
annotations/
├── Isolate_001.gbk  (or .gff3)
├── Isolate_002.gbk
└── ...
```

**Proteomes:**
```
proteomes/
├── Isolate_001.faa
├── Isolate_002.faa
└── ...
```

**Effectors:**
```
effectors/
├── Isolate_001_effectors.fasta
├── Isolate_002_effectors.fasta
└── ...
```

**Phenotypes (CSV):**

*growth_rate_heat_cold.csv* – Long format:
```
sample,condition,temperature,replicate,growth_rate
Isolate_001,heat,40,1,2.5
Isolate_001,heat,40,2,2.3
Isolate_001,cold,5,1,0.8
...
```

*growth_rate_optimum.csv* – One diameter per isolate (replicates OK):
```
sample,diameter_mm
Isolate_001,80.5
Isolate_001,82.1
Isolate_002,75.3
...
```

*barley_pathogenicity.csv* – Raw assay data:
```
sample,replicate,virulence_metric
Isolate_001,1,45.2
Isolate_001,2,43.8
Isolate_002,1,62.1
...
```

---

## Running the Pipeline

Each script is SLURM-ready and can run independently or sequentially.

### **Sequential Execution (Recommended)**

```bash
cd /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs

sbatch ../../path/to/01_genome_stats.sh
sbatch ../../path/to/02_accessory_genome.sh
sbatch ../../path/to/03_synteny.sh
sbatch ../../path/to/04_effector_analysis.sh
sbatch ../../path/to/05_cazyme_annotation.sh
sbatch ../../path/to/06_phenotype_parsing.sh
sbatch ../../path/to/07_correlation_analysis.sh
```

Then generate figures:

```bash
# Load required modules and activate environment
module load miniconda
source activate mycotools  # or your Python env with matplotlib/seaborn

python3 ../../path/to/08_generate_figures.py /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs
```

---

## Script Descriptions

### **01_genome_stats.sh** (30 min, 4 CPU, 8 GB)
**Generates:** Fig 4a  
**Outputs:**
- `genome_stats_summary.tsv`: genome size, GC%, scaffold count, N50, repeat content

Extracts structural variation metrics for each isolate.

---

### **02_accessory_genome.sh** (1 h, 8 CPU, 16 GB)
**Generates:** Fig 4b  
**Outputs:**
- `gene_presence_absence.tsv`: binary matrix (1/0)
- `gene_presence_absence_classified.tsv`: core vs accessory classification
- `accessory_summary.tsv`: core/accessory counts per isolate

Identifies core genes (present in ≥11/12 isolates) and accessory genes via GBK locus_tag extraction.

---

### **03_synteny.sh** (4 h, 16 CPU, 32 GB)
**Generates:** Fig 4c  
**Tools:** minimap2 (asm5 mode)  
**Outputs:**
- `paf/`: raw minimap2 alignments
- `synteny_pairwise.tsv`: per-pair alignment stats + synteny break counts
- `fusions/lineage_specific_breakpoints.bed`: BED file of rearrangement regions
- `fusions/lineage_specific_fissions.tsv`: high-breakpoint species pairs

Detects chromosomal fusions/fissions by aligning all isolates pairwise and counting synteny breaks (gap >10kb).

---

### **04_effector_analysis.sh** (1.5 h, 8 CPU, 16 GB)
**Generates:** Fig 4d  
**Outputs:**
- `effector_counts.tsv`: total effectors + effectors/Mb per isolate
- `effector_families.tsv`: CD-HIT family assignments (if module available)
- `effector_expansion_summary.tsv`: species-level expansion metrics (max/min ratio)
- `effector_diversity.tsv`: Shannon & Simpson diversity indices

Processes effector FASTA files and identifies expansions/contractions by species.

---

### **05_cazyme_annotation.sh** (6 h, 16 CPU, 32 GB)
**Generates:** Fig 5 (left panels)  
**Tools:** dbCAN (module or conda)  
**Outputs:**
- `raw_output/`: per-isolate dbCAN output
- `cazyme_summary.tsv`: total CAzymes + family breakdown (GH, GT, PL, CE) per isolate
- `parsed/cazyme_profiles.tsv`: individual CAzyme assignments
- `cazyme_diversity.tsv`: species-level CAzyme profiles

Runs dbCAN on all proteomes to annotate carbohydrate-active enzymes.

---

### **06_phenotype_parsing.sh** (30 min, 4 CPU, 8 GB)
**Generates:** Figs 1, 2, 3, 4  
**Outputs:**
- `growth_rates_summary.tsv`: heat/cold stress means ± SEM (Fig 1 & 2)
- `growth_rates_optimum_summary.tsv`: optimum temp diameter data (Fig 3)
- `pathogenicity_summary.tsv`: virulence scores + severity classification (Fig 4)
- `merged_phenotypes.tsv`: all phenotypes in one table (for correlation)

Parses CSV phenotype files and computes summary statistics.

---

### **07_correlation_analysis.sh** (1 h, 4 CPU, 8 GB)
**Generates:** Fig 5 (right panels, correlations)  
**Tools:** Python (scipy, pandas)  
**Outputs:**
- `correlation_data.tsv`: merged CAzyme + virulence table
- `correlation_matrix.tsv`: Pearson & Spearman r values
- `correlation_pvalues.tsv`: p-values
- `correlation_summary.tsv`: significant associations (p < 0.05)
- `species_cazyme_virulence.tsv`: species-level summary

Tests associations between CAzyme counts (total, GH, GT, PL, CE) and virulence.

---

### **08_generate_figures.py**
**Generates:** All 9 figures  
**Usage:**
```bash
python3 08_generate_figures.py /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs
```

**Output:**
```
08_figures/
├── Fig1_Heat_Stress.png
├── Fig2_Cold_Stress.png
├── Fig3_Optimum_Growth.png
├── Fig4_Barley_Pathogenicity.png
├── Fig4a_Structural_Variation.png
├── Fig4b_Accessory_Genes.png
├── Fig4c_Chromosomal_Fissions.png
├── Fig4d_Effector_Expansions.png
└── Fig5_CAzyme_Virulence.png
```

All PNG files are 300 DPI, suitable for publication.

---

## Tools & Requirements

### **Ceres Modules**
```bash
module load minimap2          # For synteny (03_synteny.sh)
module load dbcan             # For CAzyme annotation (05_cazyme_annotation.sh)
module load miniconda          # For Python/correlation analysis
```

### **Optional Ceres Modules**
```bash
module load cdhit             # For effector clustering (improves 04_effector_analysis.sh)
```

### **Conda Environment**
If using conda (recommended for dbCAN):
```bash
# Set up once:
conda create -n cazyme_env python=3.9 -y
conda activate cazyme_env
pip install dbcan scipy pandas matplotlib seaborn
```

---

## Troubleshooting

### **"module not found"**
- Substitute with conda environment or system PATH tool
- Edit script to use fallback commands

### **Empty output files**
- Check that input FASTA/CSV files are in `00_input/`
- Verify file naming matches `barlist.tsv` 
- Check script logs in `logs/` directory

### **dbCAN fails**
- Ensure dbCAN databases are downloaded: `dbcan_setup` (if available)
- Use conda environment if module unavailable
- fallback: skip 05_cazyme_annotation.sh, skip Fig 5

### **minimap2 alignment too slow**
- Reduce number of pairwise comparisons in 03_synteny.sh
- Use `--genefinding-tool nucmer` instead for faster (less precise) alignment

### **Python correlation script fails**
- Ensure scipy and pandas installed: `pip install scipy pandas`
- Check that correlation_data.tsv was generated in 07_correlation/

---

## Output Interpretation

### **Fig 1 & 2: Growth Rates**
- X-axis: Fusarium species
- Y-axis: Growth rate (mm/day) under heat/cold stress
- Error bars: standard deviation

### **Fig 3: Optimum Growth**
- X-axis: Species
- Y-axis: Colony diameter (mm) at 7 days, optimum temperature

### **Fig 4: Pathogenicity**
- X-axis: Isolates (sorted by virulence)
- Y-axis: Virulence score (higher = more pathogenic)
- Bar color: infection severity (red = high, orange = moderate, green = low)

### **Fig 4a: Structural Variation**
- 4-panel subplot: genome size, GC%, scaffold count, N50

### **Fig 4b: Accessory Genes**
- Stacked bar: core vs accessory gene counts
- Scatter: gene count variation across isolates

### **Fig 4c: Chromosomal Fissions**
- Bar: top 12 species pairs by synteny break count
- Scatter: query coverage vs rearrangement frequency

### **Fig 4d: Effector Expansions**
- Bar: effector counts per isolate (sorted)
- Bar: effector density (per Mb)
- Box: expansion distribution by species

### **Fig 5: CAzyme-Virulence**
- Top: stacked CAzyme family counts (GH, GT, PL, CE)
- Left-middle: CAzyme counts per isolate
- Right-middle: CAzyme % by species
- Bottom: correlation scatter plots (CAzymes vs virulence, GH vs virulence)
  - Red dashed line: linear fit

---

## Advanced: Customizing Figures

Edit `08_generate_figures.py` to:
- Change color palettes: `sns.set_palette("Set2")` → other seaborn palettes
- Adjust figure sizes: `figsize=(12, 6)` 
- Change statistical tests: `errorbar='sd'` → `'sem'`, `'ci'`, etc.
- Add/remove subplots: modify axes definitions in each function

---

## Citation

If you use this pipeline, cite the tools:
- **minimap2:** Li et al. 2018 (Bioinformatics)
- **dbCAN:** Zhang et al. 2018 (Nucleic Acids Research)
- **seaborn/matplotlib:** Hunter et al. (Matplotlib), Waskom (seaborn)

---

## Contact

For issues, check script logs in `logs/` or re-run individual scripts with verbose output (`set -x`).

---

**Last Updated:** 2026-07-04
