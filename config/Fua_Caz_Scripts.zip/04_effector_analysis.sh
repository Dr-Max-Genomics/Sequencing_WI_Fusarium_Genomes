#!/bin/bash
#SBATCH --job-name=effector_analysis
#SBATCH --time=01:30:00
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/04_effector_analysis"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"

exec > ${LOG_DIR}/04_effector_analysis_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 04: EFFECTOR GENE EXPANSIONS (Fig 4d)
# ============================================================================
# Analyzes effector repertoires across the 12 isolates.
# Identifies:
#   - Total effector counts per isolate
#   - Effector families (using simple sequence homology clustering)
#   - Species-specific/lineage-specific expansions
#   - Effector diversity metrics
#
# Outputs:
#   - effector_counts.tsv: count per isolate
#   - effector_families.tsv: family assignments
#   - effector_expansion_summary.tsv: expansion metrics per species
# ============================================================================

echo "=== Effector Gene Analysis ==="
echo "Input: ${INPUT_DIR}/effectors/"
echo "Output: ${OUTPUT_DIR}/"
echo ""

BARLIST="${ANALYSIS_ROOT}/barlist.tsv"

# ========== COUNT EFFECTORS PER ISOLATE ==========
echo "Counting effector proteins per isolate..."

EFFECTOR_COUNTS="${OUTPUT_DIR}/effector_counts.tsv"
cat > "$EFFECTOR_COUNTS" << 'HEADER'
sample	isolate	species	num_effectors	proteins_per_mb
HEADER

# Get genome size from genome_stats (if available)
GENOME_STATS="${ANALYSIS_ROOT}/01_genome_stats/genome_stats_summary.tsv"

while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    EFFECTOR_FASTA="${INPUT_DIR}/effectors/${sample}_effectors.fasta"
    if [[ ! -f "$EFFECTOR_FASTA" ]]; then
        echo "WARNING: ${EFFECTOR_FASTA} not found. Skipping ${sample}."
        continue
    fi
    
    # Count sequences (effectors)
    NUM_EFFECTORS=$(grep -c "^>" "$EFFECTOR_FASTA" || echo "0")
    
    # Get genome size for normalization
    GENOME_MB="NA"
    if [[ -f "$GENOME_STATS" ]]; then
        GENOME_MB=$(awk -v s="$sample" '$1 == s {printf "%.2f", $4/1e6; exit}' "$GENOME_STATS")
    fi
    
    # Calculate effectors per Mb
    if [[ "$GENOME_MB" != "NA" ]]; then
        EFFECTORS_PER_MB=$(awk "BEGIN {printf \"%.2f\", $NUM_EFFECTORS / $GENOME_MB}")
    else
        EFFECTORS_PER_MB="NA"
    fi
    
    echo -e "${sample}\t${isolate}\t${species}\t${NUM_EFFECTORS}\t${EFFECTORS_PER_MB}"
    
done < "$BARLIST" >> "$EFFECTOR_COUNTS"

echo "✓ Effector counts: $EFFECTOR_COUNTS"
cat "$EFFECTOR_COUNTS"

# ========== CLUSTER EFFECTORS INTO FAMILIES ==========
# Simple approach: group by sequence similarity using CD-HIT clustering
# (install cd-hit on Ceres, or use fallback)

echo ""
echo "Clustering effectors into families (CD-HIT)..."

# Combine all effectors
COMBINED_EFFECTORS="${OUTPUT_DIR}/.all_effectors.fasta"
cat "${INPUT_DIR}/effectors/"*_effectors.fasta > "$COMBINED_EFFECTORS" 2>/dev/null || true

if [[ ! -s "$COMBINED_EFFECTORS" ]]; then
    echo "WARNING: No effector files found. Skipping clustering."
else
    # Try to load cd-hit module; if not available, skip clustering
    if module load cdhit 2>/dev/null || which cd-hit >/dev/null 2>&1; then
        CLUSTERED="${OUTPUT_DIR}/effectors_clustered.fasta"
        CLUSTER_INFO="${OUTPUT_DIR}/effectors.clstr"
        
        # Cluster at 80% identity, 0.8 coverage
        cd-hit -i "$COMBINED_EFFECTORS" -o "$CLUSTERED" -c 0.8 -n 5 -d 0 \
            -T 8 -M 16000 2>/dev/null || echo "cd-hit run completed (check stderr)"
        
        # Parse cluster file to get family assignments
        if [[ -f "$CLUSTER_INFO" ]]; then
            FAMILY_ASSIGNMENTS="${OUTPUT_DIR}/effector_families.tsv"
            cat > "$FAMILY_ASSIGNMENTS" << 'HEADER_FAM'
effector_id	family_id	cluster_size	isolate	species
HEADER_FAM
            
            awk '
            /^>Cluster/ {
                cluster_id = $2
                cluster_count = 0
            }
            /^[0-9]+/ {
                match($0, />([^ ]*)/, arr)
                effector_id = arr[1]
                cluster_count++
                
                # Extract isolate from sequence header (e.g., "SAMPLE_eff001")
                match(effector_id, /^([^_]*)/, iso_arr)
                isolate = iso_arr[1]
                
                print effector_id "\t" cluster_id "\t" cluster_count "\t" isolate
            }
            ' "$CLUSTER_INFO" >> "$FAMILY_ASSIGNMENTS"
            
            echo "✓ Effector families: $FAMILY_ASSIGNMENTS"
        fi
    else
        echo "Note: cd-hit not available. Skipping clustering (optional)."
    fi
fi

# ========== EXPANSION ANALYSIS BY SPECIES ==========
echo ""
echo "Identifying species-specific effector expansions..."

EXPANSION_SUMMARY="${OUTPUT_DIR}/effector_expansion_summary.tsv"
cat > "$EXPANSION_SUMMARY" << 'HEADER'
species	mean_effectors	std_effectors	min_effectors	max_effectors	expansion_index
HEADER

# Compute stats per species
while read -r species; do
    [[ -z "$species" ]] && continue
    
    COUNTS=$(awk -v sp="$species" '$3 == sp {print $4}' "$EFFECTOR_COUNTS" | sort -n)
    
    if [[ -z "$COUNTS" ]]; then
        continue
    fi
    
    MEAN=$(echo "$COUNTS" | awk '{sum+=$1; count++} END {printf "%.2f", sum/count}')
    
    # Standard deviation
    STD=$(echo "$COUNTS" | awk -v m="$MEAN" '{sum+=($1-m)^2; count++} END {printf "%.2f", sqrt(sum/(count-1))}' 2>/dev/null || echo "NA")
    
    MIN=$(echo "$COUNTS" | head -1)
    MAX=$(echo "$COUNTS" | tail -1)
    
    # Expansion index: ratio of max to min
    EXPANSION_IDX=$(awk "BEGIN {printf \"%.2f\", $MAX / $MIN}")
    
    echo -e "${species}\t${MEAN}\t${STD}\t${MIN}\t${MAX}\t${EXPANSION_IDX}"
    
done < <(awk 'NR > 1 {print $3}' "$EFFECTOR_COUNTS" | sort | uniq) >> "$EXPANSION_SUMMARY"

echo "✓ Expansion summary: $EXPANSION_SUMMARY"
cat "$EXPANSION_SUMMARY"

# ========== EFFECTOR DIVERSITY METRICS ==========
# Shannon diversity, Simpson index per species

echo ""
echo "Computing diversity metrics..."

DIVERSITY_METRICS="${OUTPUT_DIR}/effector_diversity.tsv"
cat > "$DIVERSITY_METRICS" << 'HEADER'
species	shannon_diversity	simpson_index	richness
HEADER

while read -r species; do
    [[ -z "$species" ]] && continue
    
    COUNTS=$(awk -v sp="$species" '$3 == sp {print $4}' "$EFFECTOR_COUNTS")
    N_ISOLATES=$(echo "$COUNTS" | wc -l)
    
    if [[ $N_ISOLATES -lt 1 ]]; then
        continue
    fi
    
    # Shannon diversity: -sum(p_i * ln(p_i))
    SHANNON=$(echo "$COUNTS" | awk -v n="$N_ISOLATES" '
    {
        total += $1
    }
    END {
        for (i in data) shannon += (data[i]/total) * log(data[i]/total)
        print -shannon
    }' 2>/dev/null || echo "NA")
    
    # Simpson index: 1 - sum(p_i^2)
    SIMPSON=$(echo "$COUNTS" | awk -v n="$N_ISOLATES" '
    {
        total += $1
    }
    END {
        for (i in data) simpson += (data[i]/total)^2
        print 1 - simpson
    }' 2>/dev/null || echo "NA")
    
    # Richness = number of isolates
    RICHNESS=$N_ISOLATES
    
    echo -e "${species}\t${SHANNON}\t${SIMPSON}\t${RICHNESS}"
    
done < <(awk 'NR > 1 {print $3}' "$EFFECTOR_COUNTS" | sort | uniq) >> "$DIVERSITY_METRICS"

echo "✓ Diversity metrics: $DIVERSITY_METRICS"
cat "$DIVERSITY_METRICS"

# Cleanup
rm -f "$COMBINED_EFFECTORS"

# ========== SUMMARY ==========
echo ""
echo "=== Effector Gene Analysis Complete ==="
echo "Outputs:"
echo "  - effector_counts.tsv: total effectors per isolate"
echo "  - effector_families.tsv: family assignments (if cd-hit available)"
echo "  - effector_expansion_summary.tsv: species-level expansion metrics"
echo "  - effector_diversity.tsv: Shannon & Simpson diversity indices"

exit 0
