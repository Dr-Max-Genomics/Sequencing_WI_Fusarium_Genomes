#!/bin/bash
#SBATCH --job-name=accessory_genome
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/02_accessory_genome"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"

exec > ${LOG_DIR}/02_accessory_genome_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 02: MACRO-STRUCTURAL & ACCESSORY GENE VARIATION (Fig 4b)
# ============================================================================
# Identifies presence/absence of genes across isolates using GBK locus_tags.
# Generates:
#   - gene_presence_absence.tsv (binary matrix: 1 = present, 0 = absent)
#   - accessory_summary.tsv (core vs accessory gene counts per isolate)
#
# Core genes: present in ≥11/12 isolates
# Accessory genes: present in <11/12 isolates
# ============================================================================

echo "=== Accessory Genome Analysis ==="
echo "Input: ${INPUT_DIR}/annotations/"
echo "Output: ${OUTPUT_DIR}/"
echo ""

BARLIST="${ANALYSIS_ROOT}/barlist.tsv"
if [[ ! -f "$BARLIST" ]]; then
    echo "ERROR: barlist.tsv not found."
    exit 1
fi

# ========== EXTRACT GENES FROM GBK FILES ==========
# For each isolate, extract gene locus_tag and product annotation

echo "Extracting genes from GBK files..."

TEMP_GENELISTS="${OUTPUT_DIR}/.temp_genelists"
mkdir -p "$TEMP_GENELISTS"

# Helper: extract locus_tags from GBK
extract_genes_from_gbk() {
    local gbk_file="$1"
    local prefix="$2"
    
    if [[ ! -f "$gbk_file" ]]; then
        echo "WARNING: $gbk_file not found"
        return 1
    fi
    
    # Use grep/sed to find /locus_tag and /product pairs
    # Output: locus_tag <TAB> product
    awk '
    /\/locus_tag=/ { 
        match($0, /locus_tag="([^"]*)"/, arr)
        locus = arr[1]
        getline
        while ($0 !~ /\/locus_tag=/ && $0 !~ /^\/\// && NF > 0) {
            if ($0 ~ /\/product=/) {
                match($0, /product="([^"]*)"/, arr2)
                product = arr2[1]
                print locus "\t" product
                break
            }
            getline
        }
    }
    ' "$gbk_file" | sort | uniq
}

# Extract genes for all isolates
while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    GBK_FILE="${INPUT_DIR}/annotations/${sample}.gbk"
    if [[ ! -f "$GBK_FILE" ]]; then
        echo "WARNING: ${GBK_FILE} not found. Skipping ${sample}."
        continue
    fi
    
    echo "  Extracting: $sample"
    extract_genes_from_gbk "$GBK_FILE" "$sample" > "${TEMP_GENELISTS}/${sample}.genes.txt"
    
done < "$BARLIST"

# ========== BUILD GENE PRESENCE/ABSENCE MATRIX ==========
echo ""
echo "Building presence/absence matrix..."

# Get all unique genes across all isolates
cat "${TEMP_GENELISTS}"/*.genes.txt | cut -f1 | sort | uniq > "${TEMP_GENELISTS}/all_genes.txt"
TOTAL_GENES=$(wc -l < "${TEMP_GENELISTS}/all_genes.txt")
echo "Total unique genes: $TOTAL_GENES"

# Build matrix: rows = genes, columns = isolates
{
    # Header
    echo -n "locus_tag"
    while IFS=$'\t' read -r sample species strain isolate; do
        [[ "$sample" == "sample" ]] && continue
        echo -n -e "\t${sample}"
    done < "$BARLIST"
    echo ""
    
    # For each gene, check presence in each isolate
    while read -r gene; do
        echo -n "$gene"
        
        while IFS=$'\t' read -r sample species strain isolate; do
            [[ "$sample" == "sample" ]] && continue
            
            if grep -q "^${gene}" "${TEMP_GENELISTS}/${sample}.genes.txt" 2>/dev/null; then
                echo -n -e "\t1"
            else
                echo -n -e "\t0"
            fi
        done < "$BARLIST"
        echo ""
        
    done < "${TEMP_GENELISTS}/all_genes.txt"
    
} > "${OUTPUT_DIR}/gene_presence_absence.tsv"

echo "✓ Presence/absence matrix: ${OUTPUT_DIR}/gene_presence_absence.tsv"

# ========== CLASSIFY CORE vs ACCESSORY GENES ==========
echo ""
echo "Classifying core vs accessory genes..."

TOTAL_ISOLATES=$(grep -v "^sample" "$BARLIST" | wc -l)
CORE_THRESHOLD=$(echo "$TOTAL_ISOLATES - 1" | bc)  # ≥11/12

# Add classification column
{
    head -1 "${OUTPUT_DIR}/gene_presence_absence.tsv"
    
    tail -n +2 "${OUTPUT_DIR}/gene_presence_absence.tsv" | while read -r line; do
        locus=$(echo "$line" | cut -f1)
        presence_count=$(echo "$line" | cut -f2- | tr '\t' '\n' | grep -c "^1$")
        
        if [[ $presence_count -ge $CORE_THRESHOLD ]]; then
            classification="core"
        else
            classification="accessory"
        fi
        
        echo -e "${line}\t${presence_count}\t${classification}"
    done
    
} > "${OUTPUT_DIR}/gene_presence_absence_classified.tsv"

echo "✓ Classified matrix: ${OUTPUT_DIR}/gene_presence_absence_classified.tsv"

# ========== SUMMARY STATISTICS ==========
echo ""
echo "Generating summary statistics..."

cat > "${OUTPUT_DIR}/accessory_summary.tsv" << 'HEADER'
sample	total_genes	core_genes	accessory_genes	unique_genes
HEADER

while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    # Count total genes in this isolate
    TOTAL=$(grep -c "^" "${TEMP_GENELISTS}/${sample}.genes.txt" || echo "0")
    
    # Count core genes (present in ≥CORE_THRESHOLD isolates)
    CORE=$(awk -v col="${sample}" -v thresh="${CORE_THRESHOLD}" '
        NR == 1 { 
            for (i = 1; i <= NF; i++) {
                if ($i == col) col_idx = i
            }
        }
        NR > 1 && $(NF) == "core" { count++ }
        END { print count+0 }
    ' "${OUTPUT_DIR}/gene_presence_absence_classified.tsv")
    
    ACCESSORY=$((TOTAL - CORE))
    
    # Unique genes = genes only in this isolate
    UNIQUE=$(grep "^" "${TEMP_GENELISTS}/${sample}.genes.txt" | wc -l)
    while IFS=$'\t' read -r s2 sp2 st2 iso2; do
        [[ "$s2" == "sample" || "$s2" == "$sample" ]] && continue
        UNIQUE=$(comm -23 <(sort "${TEMP_GENELISTS}/${sample}.genes.txt" | cut -f1) \
                          <(sort "${TEMP_GENELISTS}/${s2}.genes.txt" | cut -f1) | wc -l)
    done < "$BARLIST"
    
    echo -e "${sample}\t${TOTAL}\t${CORE}\t${ACCESSORY}\t${UNIQUE}"
    
done < "$BARLIST" >> "${OUTPUT_DIR}/accessory_summary.tsv"

echo "✓ Summary statistics: ${OUTPUT_DIR}/accessory_summary.tsv"
cat "${OUTPUT_DIR}/accessory_summary.tsv"

# Cleanup
rm -rf "$TEMP_GENELISTS"

echo ""
echo "=== Accessory Genome Analysis Complete ==="
echo "Key outputs:"
echo "  - gene_presence_absence.tsv: binary matrix (1/0)"
echo "  - gene_presence_absence_classified.tsv: with core/accessory classification"
echo "  - accessory_summary.tsv: per-isolate summary"

exit 0
