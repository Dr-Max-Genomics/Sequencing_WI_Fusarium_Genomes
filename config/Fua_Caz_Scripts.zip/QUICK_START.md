# Conference Figure Pipeline: Quick Start Guide

**For Dr. Max Genomics Research**  
**Fusarium Isolate Integrative Analysis (12 isolates, heat/cold stress, barley pathogenicity)**

---

## What You're Getting

A complete, production-ready bash + Python pipeline that generates **9 publication-quality figures** from your genomic, proteomic, and phenotypic data:

| Figure | Type | Data | Output |
|--------|------|------|--------|
| **1** | Heat Stress Growth | CSV | Bar plot (species × growth rate) |
| **2** | Cold Stress Growth | CSV | Bar plot (species × growth rate) |
| **3** | Optimum Temperature | CSV | Bar plot (species × 7-day diameter) |
| **4** | Barley Pathogenicity | CSV | Bar plot (isolates × virulence, color-coded severity) |
| **4a** | Structural Variation | FASTA + GBK | 4-panel: genome size, GC%, scaffolds, N50 |
| **4b** | Accessory Gene Variation | GBK | Stacked bars (core vs accessory genes) |
| **4c** | Chromosomal Fissions | FASTA | Synteny breaks across species pairs |
| **4d** | Effector Expansions | Effector FASTA | Effector counts & density per isolate |
| **5** | CAzyme Profiles + Virulence | Proteome FASTA | CAzyme family distributions + scatter correlations |

---

## 5-Minute Setup

### **Step 1: Copy Scripts to Ceres**
```bash
# Download all scripts to your local machine, then:
scp -r ./* ceres.scinet.usda.gov:/90daydata/silage_microbiome/max.chi/MSA_2026/
```

Or clone the directory structure:
```bash
mkdir -p /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs
cd /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs
```

### **Step 2: Run Setup**
```bash
bash 00_setup.sh
```
This creates the full directory tree and generates a blank `barlist.tsv`.

### **Step 3: Edit barlist.tsv**
```bash
# Edit with your actual isolate names and species
nano barlist.tsv
```

**Expected format:**
```
sample          species         strain  isolate
Isolate_001     F. graminearum  NA      FUS001
Isolate_002     F. cerealis     NA      FUS002
... (12 total)
```

### **Step 4: Prepare Input Data**
Copy or symlink your data to `00_input/`:
```
00_input/
├── genomes/          → *.fasta (12 files)
├── annotations/      → *.gbk or *.gff3 (12 files)
├── proteomes/        → *.faa (12 files)
├── effectors/        → *_effectors.fasta (12 files)
├── growth_rate_heat_cold.csv
├── growth_rate_optimum.csv
└── barley_pathogenicity.csv
```

### **Step 5: Run Pipeline**
```bash
# Submit all analysis jobs:
sbatch 01_genome_stats.sh
sbatch 02_accessory_genome.sh
sbatch 03_synteny.sh
sbatch 04_effector_analysis.sh
sbatch 05_cazyme_annotation.sh
sbatch 06_phenotype_parsing.sh
sbatch 07_correlation_analysis.sh

# Wait for all to complete, then generate figures:
module load miniconda
source activate base  # or your Python environment with matplotlib/seaborn

python3 08_generate_figures.py /90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs
```

### **Step 6: Collect Figures**
All PNG files appear in:
```
08_figures/
├── Fig1_Heat_Stress.png
├── Fig2_Cold_Stress.png
├── Fig3_Optimum_Growth.png
├── Fig4_Barley_Pathogenicity.png
├── Fig4a_Structural_Variation.png
├── Fig4b_Accessory_Genes.png
├── Fig4c_Chromosomal_Fissions.png
├── Fig4d_Effector_Expansions.png
└── Fig5_CAzyme_Virulence.png
```

Download and use in your presentation! 🎉

---

## What Each Script Does (Detailed)

### **01_genome_stats.sh** (30 min)
Extracts from FASTA assemblies:
- Genome size (bp)
- GC content (%)
- Scaffold count
- N50 value
- Repeat content (from GFF if available)

**Output:** `genome_stats_summary.tsv`

---

### **02_accessory_genome.sh** (1 hour)
Parses GBK locus_tags to build:
- Gene presence/absence matrix (binary: 1/0)
- Core gene classification (≥11/12 isolates)
- Accessory gene counts per isolate
- Unique gene inventories

**Outputs:** 
- `gene_presence_absence.tsv`
- `gene_presence_absence_classified.tsv`
- `accessory_summary.tsv`

---

### **03_synteny.sh** (4 hours, uses minimap2)
Pairwise whole-genome alignments to detect:
- Chromosomal rearrangements (synteny breaks > 10kb gaps)
- Fusion/fission events
- Within-species vs. between-species structural variation

**Outputs:**
- `paf/`: raw minimap2 alignments
- `synteny_pairwise.tsv`: break counts per pair
- `fusions/lineage_specific_fissions.tsv`: high-variation species pairs

---

### **04_effector_analysis.sh** (1.5 hours)
From your effector FASTA files:
- Count total effectors per isolate
- Normalize by genome size (effectors/Mb)
- Cluster into families (CD-HIT, if available)
- Identify species-level expansions (max/min ratio)

**Outputs:**
- `effector_counts.tsv`
- `effector_families.tsv` (optional, if cd-hit available)
- `effector_expansion_summary.tsv`
- `effector_diversity.tsv`

---

### **05_cazyme_annotation.sh** (6 hours, uses dbCAN)
Runs dbCAN on all proteomes:
- Counts glycoside hydrolases (GH), glycosyltransferases (GT), polysaccharide lyases (PL), carbohydrate esterases (CE)
- Computes CAzyme % of proteome
- Species-level CAzyme profiles

**Outputs:**
- `cazyme_summary.tsv`
- `raw_output/`: per-isolate dbCAN logs
- `cazyme_diversity.tsv`

---

### **06_phenotype_parsing.sh** (30 min)
Processes your 3 CSV files:
- **growth_rate_heat_cold.csv** → means ± SEM per condition
- **growth_rate_optimum.csv** → 7-day diameter stats
- **barley_pathogenicity.csv** → virulence scores + severity classification

**Outputs:**
- `growth_rates_summary.tsv`
- `growth_rates_optimum_summary.tsv`
- `pathogenicity_summary.tsv`
- `merged_phenotypes.tsv` (all in one table)

---

### **07_correlation_analysis.sh** (1 hour, uses Python/scipy)
Tests associations between CAzymes and virulence:
- Pearson correlation (r, p-value)
- Spearman rank correlation (for non-normal distributions)
- Tests: total CAzymes, GH count, GT count, PL count, CE count vs. virulence

**Outputs:**
- `correlation_data.tsv` (merged CAzyme + virulence)
- `correlation_matrix.tsv` (Pearson & Spearman r)
- `correlation_pvalues.tsv` (p-values)
- `correlation_summary.tsv` (significant associations, p < 0.05)

---

### **08_generate_figures.py** (5 min)
Reads all TSV outputs and generates 9 publication-ready PNG files:
- 300 DPI (suitable for print)
- Professional styling (seaborn + matplotlib)
- Error bars where applicable
- Color-coded by species or severity
- All labels, titles, axes formatted

**Output:** `08_figures/*.png`

---

## Input File Formats

### **growth_rate_heat_cold.csv**
Long format, comma-separated:
```
sample,condition,temperature,replicate,growth_rate
Isolate_001,heat,40,1,2.5
Isolate_001,heat,40,2,2.3
Isolate_001,cold,5,1,0.8
Isolate_001,cold,5,2,0.9
Isolate_002,heat,40,1,2.1
...
```

### **growth_rate_optimum.csv**
One row per replicate (colonies at optimum temp, 7 days):
```
sample,diameter_mm
Isolate_001,80.5
Isolate_001,82.1
Isolate_001,81.2
Isolate_002,75.3
Isolate_002,76.8
...
```

### **barley_pathogenicity.csv**
Raw assay data (lesion area, % infection, etc.):
```
sample,replicate,virulence_metric
Isolate_001,1,45.2
Isolate_001,2,43.8
Isolate_002,1,62.1
Isolate_002,2,63.5
...
```

---

## Troubleshooting

### **"minimap2 not found"**
→ Load module: `module load minimap2` or install via conda

### **"dbcan not found"**
→ Load module: `module load dbcan` or conda env: `pip install dbcan`

### **Empty output files (TSV with just headers)**
→ Check input file paths in `00_input/`  
→ Verify filenames match entries in `barlist.tsv`  
→ Look at script logs: `tail logs/*.log`

### **Python script fails on correlations**
→ Install scipy/pandas: `pip install scipy pandas`  
→ Check `07_correlation/correlation_data.tsv` exists

### **Figures are ugly/colors wrong**
→ Edit `08_generate_figures.py` (lines with `sns.set_palette()`, figure sizes, colors)  
→ Re-run: `python3 08_generate_figures.py <path>`

---

## Key Design Decisions

### **Why minimap2 (not MUMmer)?**
- 10× faster on large genomes
- Still highly sensitive for assembly-level comparisons
- `-x asm5` mode optimized for ~95% identity (within-species)

### **Why CD-HIT for effector clustering?**
- Fast, widely-used approach for gene family clustering
- 80% identity threshold balances specificity/sensitivity
- Optional (script works without it)

### **Why CAzyme count vs. annotation?**
- Your proteomes are unambiguous targets for CAzyme search
- Avoids gene model bias from GBK predictions
- Normalized by proteome size (effectors/Mb)

### **Why Pearson + Spearman correlations?**
- Pearson: assumes linear, normal distributions
- Spearman: rank-based, robust to outliers
- Report both for completeness

---

## Tips for Conference

1. **Customize colors** to match your institution brand
2. **Add error bars** to Figs 1–3 (already done, but check `errorbar='sd'` vs. `'sem'`)
3. **Highlight significant correlations** in Fig 5 (add `*` for p < 0.05)
4. **Group species** in Figs 4b–d by species complex (edit 08_generate_figures.py)
5. **Add supplementary data tables** (all TSV files are publication-ready)

---

## Performance Notes

| Script | Time | CPU | RAM | Disk |
|--------|------|-----|-----|------|
| 01_genome_stats | 30 min | 4 | 8 GB | minimal |
| 02_accessory_genome | 1 h | 8 | 16 GB | ~100 MB |
| 03_synteny | **4 h** | 16 | 32 GB | ~500 MB |
| 04_effector_analysis | 1.5 h | 8 | 16 GB | ~50 MB |
| 05_cazyme_annotation | **6 h** | 16 | 32 GB | ~1 GB |
| 06_phenotype_parsing | 30 min | 4 | 8 GB | minimal |
| 07_correlation_analysis | 1 h | 4 | 8 GB | ~10 MB |
| 08_generate_figures | 5 min | 1 | 2 GB | ~20 MB |
| **Total** | **~14 hours** | – | – | ~2 GB |

*Times are estimates; actual depends on genome size and data volume.*

**Run scripts 01–07 in parallel** (each is independent after 00_setup.sh), then run 08 once all are done.

---

## What's NOT Included (Future Work)

- **Phylogenetic tree** – use IQ-TREE on core gene alignments
- **BLAST searches** – add custom queries against your genomes
- **Machine learning** – predict virulence from genomic features
- **Comparative annotation** – extract GO terms, pathway enrichment

These can all be added as additional scripts if needed!

---

## Need Help?

1. **Check logs:** Each script writes `logs/SCRIPT_NAME_${SLURM_JOB_ID}.log`
2. **Read inline comments** in scripts (dense but informative)
3. **Full documentation:** See `README_PIPELINE.md`
4. **Test with 1 isolate first** (edit barlist.tsv to have just 2–3 rows)

---

## Files Included

```
├── 00_setup.sh                      # Initialize directories & manifest
├── 01_genome_stats.sh               # Structural variation overview
├── 02_accessory_genome.sh           # Core/accessory gene analysis
├── 03_synteny.sh                    # Chromosomal fissions (minimap2)
├── 04_effector_analysis.sh          # Effector gene counts & families
├── 05_cazyme_annotation.sh          # CAzyme annotation (dbCAN)
├── 06_phenotype_parsing.sh          # Parse growth & pathogenicity CSVs
├── 07_correlation_analysis.sh       # Test CAzymes vs. virulence
├── 08_generate_figures.py           # Create all 9 publication figures
├── README_PIPELINE.md               # Full technical documentation
└── QUICK_START.md                   # This file
```

---

## License & Citation

These scripts are provided as-is. If published, cite:

- **minimap2** (Li et al. 2018)
- **dbCAN** (Zhang et al. 2018)
- **Seaborn/Matplotlib** (Waskom, Hunter et al.)

And acknowledge SCINet Ceres/Atlas for compute resources!

---

**Version:** 1.0  
**Date:** July 4, 2026  
**Status:** Ready for Production

Good luck with your conference presentation! 🍄🧬
