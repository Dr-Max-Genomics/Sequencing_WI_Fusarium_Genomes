#!/bin/bash
#SBATCH --job-name=cazyme_annotation
#SBATCH --time=06:00:00
#SBATCH --cpus-per-task=16
#SBATCH --mem=32G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/05_cazyme"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"/{raw_output,parsed}

exec > ${LOG_DIR}/05_cazyme_annotation_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 05: CAzyme ANNOTATION (dbCAN)
# ============================================================================
# Annotates carbohydrate-active enzymes (CAzymes) using dbCAN on Ceres.
# Requires: dbCAN module or conda environment with dbCAN tools
#
# Outputs:
#   - raw_output/: dbCAN output per isolate
#   - parsed/: parsed CAzyme profiles (CSV)
#   - cazyme_summary.tsv: CAzyme counts per isolate
# ============================================================================

echo "=== CAzyme Annotation (dbCAN) ==="
echo "Input: ${INPUT_DIR}/proteomes/"
echo "Output: ${OUTPUT_DIR}/"
echo ""

BARLIST="${ANALYSIS_ROOT}/barlist.tsv"

# ========== LOAD DBCAN ==========
# Try module first, then conda environment

DBCAN_CMD=""

if module load dbcan 2>/dev/null; then
    DBCAN_CMD="run_dbcan"
    echo "✓ Loaded dbCAN module"
elif module load miniconda 2>/dev/null && source activate dbcan 2>/dev/null; then
    DBCAN_CMD="run_dbcan.py"
    echo "✓ Activated dbcan conda environment"
elif which run_dbcan >/dev/null 2>&1; then
    DBCAN_CMD="run_dbcan"
    echo "✓ Found run_dbcan in PATH"
else
    echo "ERROR: dbCAN not found. Please install/module-load dbcan first."
    exit 1
fi

# ========== RUN DBCAN PER ISOLATE ==========
echo ""
echo "Running dbCAN annotation on proteomes..."

CAZYME_COUNTS="${OUTPUT_DIR}/cazyme_summary.tsv"
cat > "$CAZYME_COUNTS" << 'HEADER'
sample	isolate	species	total_proteins	total_cazymes	cazyme_percent	gh_count	gt_count	pl_count	ce_count
HEADER

CAZYME_PROFILES="${OUTPUT_DIR}/parsed/cazyme_profiles.tsv"
cat > "$CAZYME_PROFILES" << 'HEADER_PROF'
sample	isolate	species	cazyme_id	cazyme_family	protein_id	e_value
HEADER_PROF

while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    PROTEOME="${INPUT_DIR}/proteomes/${sample}.faa"
    if [[ ! -f "$PROTEOME" ]]; then
        echo "WARNING: ${PROTEOME} not found. Skipping ${sample}."
        continue
    fi
    
    echo "Processing: $sample ($species)"
    
    DBCAN_OUTPUT="${OUTPUT_DIR}/raw_output/${sample}"
    mkdir -p "$DBCAN_OUTPUT"
    
    # Run dbCAN (meta mode for best sensitivity)
    # Note: run_dbcan syntax varies by version. Common form:
    # run_dbcan.py <fasta> [options]
    
    cd "$DBCAN_OUTPUT"
    $DBCAN_CMD "$PROTEOME" --threads 16 2>/dev/null || {
        echo "dbCAN run had issues for $sample. Continuing..."
    }
    cd - >/dev/null
    
    # Parse dbCAN output (look for overview.txt or hmmer/diamond outputs)
    OVERVIEW="${DBCAN_OUTPUT}/overview.txt"
    HMMER_OUT="${DBCAN_OUTPUT}/hmmer.out"
    DIAMOND_OUT="${DBCAN_OUTPUT}/diamond.out"
    
    # Count CAzymes from hmmer output (if available)
    if [[ -f "$HMMER_OUT" ]]; then
        TOTAL_CAZYMES=$(grep -c "^" "$HMMER_OUT" || echo "0")
    elif [[ -f "$OVERVIEW" ]]; then
        # Parse overview.txt for CAzyme count
        TOTAL_CAZYMES=$(awk '/^CAzyme/ {count++} END {print count+0}' "$OVERVIEW")
    else
        TOTAL_CAZYMES=0
    fi
    
    # Count total proteins in proteome
    TOTAL_PROTEINS=$(grep -c "^>" "$PROTEOME" || echo "0")
    
    # Calculate CAzyme percentage
    if [[ $TOTAL_PROTEINS -gt 0 ]]; then
        CAZYME_PERCENT=$(awk "BEGIN {printf \"%.2f\", ($TOTAL_CAZYMES / $TOTAL_PROTEINS) * 100}")
    else
        CAZYME_PERCENT="0"
    fi
    
    # Count by family (GH, GT, PL, CE)
    GH_COUNT=0
    GT_COUNT=0
    PL_COUNT=0
    CE_COUNT=0
    
    if [[ -f "$HMMER_OUT" ]]; then
        GH_COUNT=$(grep "^GH[0-9]" "$HMMER_OUT" 2>/dev/null | wc -l || echo "0")
        GT_COUNT=$(grep "^GT[0-9]" "$HMMER_OUT" 2>/dev/null | wc -l || echo "0")
        PL_COUNT=$(grep "^PL[0-9]" "$HMMER_OUT" 2>/dev/null | wc -l || echo "0")
        CE_COUNT=$(grep "^CE[0-9]" "$HMMER_OUT" 2>/dev/null | wc -l || echo "0")
    elif [[ -f "$OVERVIEW" ]]; then
        # Parse from overview if hmmer not available
        GH_COUNT=$(awk '/^GH/ {sum+=$NF} END {print sum+0}' "$OVERVIEW")
        GT_COUNT=$(awk '/^GT/ {sum+=$NF} END {print sum+0}' "$OVERVIEW")
        PL_COUNT=$(awk '/^PL/ {sum+=$NF} END {print sum+0}' "$OVERVIEW")
        CE_COUNT=$(awk '/^CE/ {sum+=$NF} END {print sum+0}' "$OVERVIEW")
    fi
    
    # Write summary
    echo -e "${sample}\t${isolate}\t${species}\t${TOTAL_PROTEINS}\t${TOTAL_CAZYMES}\t${CAZYME_PERCENT}\t${GH_COUNT}\t${GT_COUNT}\t${PL_COUNT}\t${CE_COUNT}" >> "$CAZYME_COUNTS"
    
    # Parse individual CAzymes (if hmmer output available)
    if [[ -f "$HMMER_OUT" ]]; then
        awk -v samp="$sample" -v iso="$isolate" -v sp="$species" '
        {
            # Expected format: family protein_id e_value ...
            family = $1
            protein = $2
            evalue = $3
            print samp "\t" iso "\t" sp "\t" NR "\t" family "\t" protein "\t" evalue
        }
        ' "$HMMER_OUT" >> "$CAZYME_PROFILES"
    fi
    
done < "$BARLIST"

echo ""
echo "✓ CAzyme summary: $CAZYME_COUNTS"
cat "$CAZYME_COUNTS"

echo ""
echo "✓ CAzyme profiles: $CAZYME_PROFILES"

# ========== CAZYME DIVERSITY ANALYSIS ==========
echo ""
echo "Computing CAzyme diversity metrics..."

DIVERSITY="${OUTPUT_DIR}/cazyme_diversity.tsv"
cat > "$DIVERSITY" << 'HEADER'
species	mean_cazymes	std_cazymes	mean_percent	gh_mean	gt_mean	pl_mean	ce_mean
HEADER

awk 'NR > 1 {print $3}' "$CAZYME_COUNTS" | sort | uniq | while read -r sp; do
    [[ -z "$sp" ]] && continue
    
    # Extract CAzyme counts for this species
    COUNTS=$(awk -v s="$sp" '$3 == s {print $5}' "$CAZYME_COUNTS")
    PERCENTS=$(awk -v s="$sp" '$3 == s {print $6}' "$CAZYME_COUNTS")
    GH_COUNTS=$(awk -v s="$sp" '$3 == s {print $7}' "$CAZYME_COUNTS")
    GT_COUNTS=$(awk -v s="$sp" '$3 == s {print $8}' "$CAZYME_COUNTS")
    PL_COUNTS=$(awk -v s="$sp" '$3 == s {print $9}' "$CAZYME_COUNTS")
    CE_COUNTS=$(awk -v s="$sp" '$3 == s {print $10}' "$CAZYME_COUNTS")
    
    # Compute means
    MEAN_CAZ=$(echo "$COUNTS" | awk '{sum+=$1; count++} END {printf "%.1f", sum/count}')
    STD_CAZ=$(echo "$COUNTS" | awk -v m="$MEAN_CAZ" '{sum+=($1-m)^2; count++} END {printf "%.1f", sqrt(sum/(count-1))}' 2>/dev/null || echo "NA")
    MEAN_PCT=$(echo "$PERCENTS" | awk '{sum+=$1; count++} END {printf "%.2f", sum/count}')
    GH_MEAN=$(echo "$GH_COUNTS" | awk '{sum+=$1; count++} END {printf "%.1f", sum/count}')
    GT_MEAN=$(echo "$GT_COUNTS" | awk '{sum+=$1; count++} END {printf "%.1f", sum/count}')
    PL_MEAN=$(echo "$PL_COUNTS" | awk '{sum+=$1; count++} END {printf "%.1f", sum/count}')
    CE_MEAN=$(echo "$CE_COUNTS" | awk '{sum+=$1; count++} END {printf "%.1f", sum/count}')
    
    echo -e "${sp}\t${MEAN_CAZ}\t${STD_CAZ}\t${MEAN_PCT}\t${GH_MEAN}\t${GT_MEAN}\t${PL_MEAN}\t${CE_MEAN}"
    
done >> "$DIVERSITY"

echo "✓ CAzyme diversity: $DIVERSITY"
cat "$DIVERSITY"

# ========== SUMMARY ==========
echo ""
echo "=== CAzyme Annotation Complete ==="
echo "Outputs:"
echo "  - raw_output/: raw dbCAN output per isolate"
echo "  - cazyme_summary.tsv: per-isolate CAzyme counts"
echo "  - parsed/cazyme_profiles.tsv: individual CAzyme assignments"
echo "  - cazyme_diversity.tsv: species-level CAzyme profiles"

exit 0
