#!/bin/bash
#SBATCH --job-name=correlation_analysis
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=8G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/07_correlation"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"

exec > ${LOG_DIR}/07_correlation_analysis_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 07: CORRELATION ANALYSIS - CAzymes vs Virulence
# ============================================================================
# Tests associations between CAzyme profiles and barley pathogenicity.
# Computes Pearson & Spearman correlations.
# Tests multiple CAzyme family counts against virulence.
#
# Outputs:
#   - correlation_matrix.tsv: Pearson correlations
#   - correlation_pvalues.tsv: p-values
#   - correlation_summary.tsv: significant correlations (p < 0.05)
# ============================================================================

echo "=== Correlation Analysis: CAzymes vs Virulence ==="
echo ""

# Check required input files
CAZYME_SUMMARY="${ANALYSIS_ROOT}/05_cazyme/cazyme_summary.tsv"
PATHOGENICITY="${ANALYSIS_ROOT}/06_phenotype/pathogenicity_summary.tsv"

if [[ ! -f "$CAZYME_SUMMARY" ]]; then
    echo "ERROR: CAzyme summary not found. Run 05_cazyme_annotation.sh first."
    exit 1
fi

if [[ ! -f "$PATHOGENICITY" ]]; then
    echo "ERROR: Pathogenicity summary not found. Run 06_phenotype_parsing.sh first."
    exit 1
fi

# ========== BUILD DATA TABLE FOR CORRELATION ==========
echo "Preparing correlation data table..."

CORRELATION_DATA="${OUTPUT_DIR}/correlation_data.tsv"
cat > "$CORRELATION_DATA" << 'HEADER'
sample	total_cazymes	gh_count	gt_count	pl_count	ce_count	cazyme_percent	virulence_score
HEADER

# Join CAzyme and pathogenicity data
awk '
BEGIN { FS="\t"; OFS="\t" }
NR == FNR && NR > 1 {
    cazyme[NR] = $1 "\t" $5 "\t" $7 "\t" $8 "\t" $9 "\t" $10 "\t" $6
    next
}
NR > 1 {
    virulence[NR] = $4
}
END {
    for (i in cazyme) {
        if (i in virulence) {
            print cazyme[i] "\t" virulence[i]
        }
    }
}
' "$CAZYME_SUMMARY" "$PATHOGENICITY" | awk '!seen[$1]++' >> "$CORRELATION_DATA"

NROWS=$(awk 'END {print NR}' "$CORRELATION_DATA")
echo "✓ Correlation data table: $CORRELATION_DATA (${NROWS} isolates)"
cat "$CORRELATION_DATA"

# ========== COMPUTE CORRELATIONS USING PYTHON ==========
# Since we need scipy for robust stats, create a Python script

echo ""
echo "Computing correlations (Pearson & Spearman)..."

cat > "${OUTPUT_DIR}/compute_correlations.py" << 'PYTHON_SCRIPT'
#!/usr/bin/env python3

import sys
import pandas as pd
import numpy as np
from scipy import stats

# Read correlation data
try:
    data = pd.read_csv(sys.argv[1], sep='\t')
except Exception as e:
    print(f"Error reading file: {e}", file=sys.stderr)
    sys.exit(1)

# Remove rows with NaN values
data_clean = data.dropna()

if len(data_clean) < 3:
    print("ERROR: Not enough data points for correlation", file=sys.stderr)
    sys.exit(1)

# Define CAzyme variables and outcome
cazyme_vars = ['total_cazymes', 'gh_count', 'gt_count', 'pl_count', 'ce_count', 'cazyme_percent']
outcome = 'virulence_score'

# Initialize output tables
corr_pearson = {}
corr_spearman = {}
pval_pearson = {}
pval_spearman = {}

print("Correlation Results:")
print("-" * 60)

for var in cazyme_vars:
    if var not in data_clean.columns:
        continue
    
    # Remove rows where var or outcome is NaN
    mask = data_clean[[var, outcome]].notna().all(axis=1)
    subset = data_clean[mask]
    
    if len(subset) < 3:
        print(f"  {var}: insufficient data", file=sys.stderr)
        continue
    
    x = subset[var].values
    y = subset[outcome].values
    
    # Pearson correlation
    r_pearson, p_pearson = stats.pearsonr(x, y)
    corr_pearson[var] = r_pearson
    pval_pearson[var] = p_pearson
    
    # Spearman correlation
    r_spearman, p_spearman = stats.spearmanr(x, y)
    corr_spearman[var] = r_spearman
    pval_spearman[var] = p_spearman
    
    sig = "***" if p_pearson < 0.001 else "**" if p_pearson < 0.01 else "*" if p_pearson < 0.05 else "ns"
    print(f"  {var:20s}: r={r_pearson:7.4f} (p={p_pearson:.4f}) {sig}")

# Write output tables
with open(sys.argv[2], 'w') as f:
    f.write("variable\tpearson_r\tspearman_r\n")
    for var in cazyme_vars:
        if var in corr_pearson:
            f.write(f"{var}\t{corr_pearson[var]:.4f}\t{corr_spearman[var]:.4f}\n")

with open(sys.argv[3], 'w') as f:
    f.write("variable\tpearson_pval\tspearman_pval\n")
    for var in cazyme_vars:
        if var in pval_pearson:
            f.write(f"{var}\t{pval_pearson[var]:.4e}\t{pval_spearman[var]:.4e}\n")

with open(sys.argv[4], 'w') as f:
    f.write("variable\tcorrelation_type\tr_value\tp_value\tsignificant\n")
    for var in cazyme_vars:
        if var in corr_pearson:
            sig_p = "yes" if pval_pearson[var] < 0.05 else "no"
            sig_s = "yes" if pval_spearman[var] < 0.05 else "no"
            f.write(f"{var}\tPearson\t{corr_pearson[var]:.4f}\t{pval_pearson[var]:.4e}\t{sig_p}\n")
            f.write(f"{var}\tSpearman\t{corr_spearman[var]:.4f}\t{pval_spearman[var]:.4e}\t{sig_s}\n")

print("\nCorrelations computed successfully.")
PYTHON_SCRIPT

chmod +x "${OUTPUT_DIR}/compute_correlations.py"

# Try to run with system Python (requires scipy/pandas)
module load miniconda 2>/dev/null && source activate base 2>/dev/null || true

if python3 "${OUTPUT_DIR}/compute_correlations.py" \
    "$CORRELATION_DATA" \
    "${OUTPUT_DIR}/correlation_matrix.tsv" \
    "${OUTPUT_DIR}/correlation_pvalues.tsv" \
    "${OUTPUT_DIR}/correlation_summary.tsv" 2>/dev/null; then
    
    echo "✓ Correlation matrix: ${OUTPUT_DIR}/correlation_matrix.tsv"
    echo "✓ P-values: ${OUTPUT_DIR}/correlation_pvalues.tsv"
    echo "✓ Summary: ${OUTPUT_DIR}/correlation_summary.tsv"
    
    # Display results
    echo ""
    echo "=== Correlation Summary ==="
    cat "${OUTPUT_DIR}/correlation_summary.tsv"
else
    echo "WARNING: Python correlation failed. Attempting bash fallback (less powerful)."
    
    # Bash fallback: simple correlation coefficient calculation
    cat > "${OUTPUT_DIR}/correlation_matrix.tsv" << 'FALLBACK'
variable	pearson_r	spearman_r
# Manual calculation required; bash limitations prevent precise correlation computation
# Please compute in R or Python separately
FALLBACK

fi

# ========== CREATE SPECIES-LEVEL CORRELATION SUMMARY ==========
echo ""
echo "Generating species-level correlation summary..."

SPECIES_CORR="${OUTPUT_DIR}/species_cazyme_virulence.tsv"
cat > "$SPECIES_CORR" << 'HEADER'
species	mean_cazymes	mean_virulence	pearson_r	p_value
HEADER

awk '
BEGIN { FS="\t"; OFS="\t" }
NR > 1 {
    sp = $3
    cazyme_count[sp] = cazyme_count[sp] " " $2
    virulence[sp] = virulence[sp] " " $7
}
END {
    for (sp in cazyme_count) {
        split(cazyme_count[sp], caz_arr)
        split(virulence[sp], vir_arr)
        
        caz_sum = 0
        vir_sum = 0
        count = 0
        for (i in caz_arr) {
            if (caz_arr[i] ~ /^[0-9]/) {
                caz_sum += caz_arr[i]
                vir_sum += vir_arr[i]
                count++
            }
        }
        
        if (count > 0) {
            caz_mean = caz_sum / count
            vir_mean = vir_sum / count
            print sp "\t" caz_mean "\t" vir_mean "\tNA\tNA"
        }
    }
}
' "$CORRELATION_DATA" >> "$SPECIES_CORR"

echo "✓ Species-level CAzyme-virulence: $SPECIES_CORR"

# ========== SUMMARY ==========
echo ""
echo "=== Correlation Analysis Complete ==="
echo "Outputs:"
echo "  - correlation_data.tsv: merged data table"
echo "  - correlation_matrix.tsv: Pearson & Spearman r values"
echo "  - correlation_pvalues.tsv: p-values"
echo "  - correlation_summary.tsv: significant associations"
echo "  - species_cazyme_virulence.tsv: species-level summary"

exit 0
