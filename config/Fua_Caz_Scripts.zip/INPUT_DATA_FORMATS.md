# Input Data Format Specifications

This document specifies the exact format expected for each input file in the conference figure pipeline.

---

## 1. GENOME DATA

### **genomes/*.fasta**
Standard FASTA format. One file per isolate.

**Required:**
- File naming: `{SAMPLE}.fasta` where `{SAMPLE}` matches `barlist.tsv`
- Header format: `>scaffold_name [optional description]`
- Sequence: ATGC (uppercase or lowercase, case-insensitive)
- No special characters in header (script will parse up to first space)

**Example:**
```
>Isolate_001_scaffold_001
ATGCATGCATGC...
>Isolate_001_scaffold_002
ATGCATGCATGC...
```

**Tools to generate:**
- From Flye assembly: already in FASTA
- From raw ONT reads: use `flye --nano-corr --genome-size 40m`

---

## 2. ANNOTATION DATA

### **annotations/*.gbk** (Preferred) or **annotations/*.gff3**
GenBank or GFF3 format. One per isolate.

**For GBK (preferred):**
- File naming: `{SAMPLE}.gbk`
- Must contain `/locus_tag="XYZ"` and `/product="..."` fields
- Required fields per gene: locus_tag (unique), product (annotation)
- Optional but helpful: /gene, /EC_number

**Example GBK snippet:**
```
FEATURES             Location/Qualifiers
     gene            1..1200
                     /gene="FUS_00001"
                     /locus_tag="FUS_00001"
     CDS             1..1200
                     /product="hypothetical protein"
                     /gene="FUS_00001"
                     /locus_tag="FUS_00001"
```

**For GFF3:**
- File naming: `{SAMPLE}.gff3`
- Standard GFF3 format (9 columns, tab-separated)
- Script parses: feature type (column 3), coordinates (columns 4–5), attributes (column 9)
- Attributes must include: ID=... (unique identifier)

**Example GFF3 snippet:**
```
scaffold_001	funannotate	gene	1	1200	.	+	.	ID=gene_FUS_00001
scaffold_001	funannotate	mRNA	1	1200	.	+	.	ID=mRNA_FUS_00001;Parent=gene_FUS_00001
scaffold_001	funannotate	CDS	1	1200	.	+	0	ID=CDS_FUS_00001;Parent=mRNA_FUS_00001
```

**Tools to generate:**
- From funannotate: `funannotate predict` + `funannotate annotate` (outputs GBK)
- From standard GFF: already in GFF3 format
- From AGAT tools: `agat_convert_sp_gff2gbk.pl`

---

## 3. PROTEOME DATA

### **proteomes/*.faa**
FASTA amino acid sequences. One per isolate.

**Required:**
- File naming: `{SAMPLE}.faa` (matches `barlist.tsv`)
- Header format: `>{PROTEIN_ID} [optional description]`
- Sequence: Standard amino acids (ACDEFGHIKLMNPQRSTVWY, X, *, -)
- One protein per sequence
- Ideally: one protein per gene (no isoforms)

**Example:**
```
>FUS_00001 hypothetical protein
MKFLSQSTVLN...
>FUS_00002 oxidoreductase
MPQILVVFGL...
```

**Tools to generate:**
- From funannotate: `funannotate predict` outputs `.proteins.fa`
- From GBK: use `seqkit` or `transeq` (EMBOSS)
- From raw genes: translate with `prodigal` or `glimmer`

**Naming convention:** Script uses `${SAMPLE}.faa` to match genome/annotation files.

---

## 4. EFFECTOR DATA

### **effectors/*_effectors.fasta** or **effectors/{SAMPLE}_effectors.fasta**
FASTA amino acid sequences of predicted effector proteins.

**Required:**
- File naming: `{SAMPLE}_effectors.fasta` (matches `barlist.tsv` + "_effectors.fasta" suffix)
- Header format: `>{EFFECTOR_ID} [source/prediction tool]`
- Sequence: Standard amino acids
- One effector per sequence

**Example:**
```
>FUS_00001_eff hypothetical secreted protein (SignalP)
MLSFLFLSLVS...
>FUS_00045_eff candidate effector (EffectorP)
MPQILVVFGL...
```

**Tools to generate:**
- From antiSMASH: extract from GBK output
- From SignalP + TMHMM: filter secreted proteins
- From EffectorP: sequence-based predictions
- From database (e.g., Effectordb): BLAST queries

**Important:** 
- Must be subset of full proteome (script counts as % of total)
- If you have one combined effector FASTA for all isolates, split it by sample ID:
  ```bash
  # Example split script:
  grep "Isolate_001" all_effectors.fasta > Isolate_001_effectors.fasta
  grep "Isolate_002" all_effectors.fasta > Isolate_002_effectors.fasta
  ```

---

## 5. PHENOTYPE DATA (CSV)

All CSVs are comma-separated (not tab-separated).

### **growth_rate_heat_cold.csv** – Heat & Cold Stress Growth

**Required columns:**
1. `sample` – Isolate name (matches `barlist.tsv`)
2. `condition` – Either `heat` or `cold` (case-sensitive)
3. `temperature` – Numeric temperature (°C)
4. `replicate` – Replicate number (1, 2, 3, ...)
5. `growth_rate` – Numeric growth rate (mm/day or equivalent unit)

**Format:** Header row + data rows (no missing values in critical columns)

**Example:**
```csv
sample,condition,temperature,replicate,growth_rate
Isolate_001,heat,40,1,2.5
Isolate_001,heat,40,2,2.3
Isolate_001,heat,40,3,2.4
Isolate_001,cold,5,1,0.8
Isolate_001,cold,5,2,0.9
Isolate_002,heat,40,1,2.1
Isolate_002,heat,40,2,2.0
Isolate_002,cold,5,1,1.1
Isolate_002,cold,5,2,1.0
```

**Units:**
- `temperature`: Celsius
- `growth_rate`: mm/day (or cm/day, script normalizes as-is)
- `replicate`: integer ≥ 1

**Notes:**
- One row per replicate per condition per isolate
- Script computes mean, SD, SEM per condition
- Condition names are case-sensitive: use `heat` or `cold` (lowercase)

---

### **growth_rate_optimum.csv** – Optimum Temperature (7-day diameter)

**Required columns:**
1. `sample` – Isolate name (matches `barlist.tsv`)
2. `diameter_mm` – Colony diameter in mm after 7 days at optimum temperature

**Format:** Header row + data rows

**Example:**
```csv
sample,diameter_mm
Isolate_001,80.5
Isolate_001,82.1
Isolate_001,81.2
Isolate_002,75.3
Isolate_002,76.8
Isolate_002,75.9
Isolate_003,88.2
Isolate_003,87.5
```

**Notes:**
- One or more rows per isolate (multiple replicates OK)
- Script computes mean ± SEM
- Units in mm (if you have cm, convert: 1 cm = 10 mm)
- Optimum temperature assumed same for all isolates (not in CSV)

---

### **barley_pathogenicity.csv** – Barley Seedling Infection Assay

**Required columns:**
1. `sample` – Isolate name (matches `barlist.tsv`)
2. `replicate` – Replicate number (1, 2, 3, ...)
3. `virulence_metric` – Numeric value (lesion area mm², % leaf area infected, etc.)

**Format:** Header row + data rows

**Example (lesion area):**
```csv
sample,replicate,virulence_metric
Isolate_001,1,45.2
Isolate_001,2,43.8
Isolate_001,3,46.1
Isolate_002,1,62.1
Isolate_002,2,63.5
Isolate_002,3,61.9
Isolate_003,1,28.3
Isolate_003,2,29.1
Isolate_003,3,27.8
```

**Alternative example (% infection):**
```csv
sample,replicate,virulence_metric
Isolate_001,1,25.5
Isolate_001,2,23.8
Isolate_002,1,62.1
Isolate_002,2,63.5
```

**Notes:**
- One row per replicate per isolate
- `virulence_metric`: any numeric measure of pathogenicity (higher = more severe)
- Script classifies as:
  - `low`: < 25th percentile
  - `moderate`: 25–75th percentile
  - `high`: > 75th percentile (thresholds at script lines ~180)
- Units: mm² (lesion area), % (infection), or normalized scale (0–100)

---

## 6. SAMPLE MANIFEST

### **barlist.tsv** – Sample Key

**Required columns (tab-separated):**
1. `sample` – Isolate identifier (used as filename prefix)
2. `species` – Fusarium species (e.g., `F. graminearum`)
3. `strain` – Strain designation (can be `NA`)
4. `isolate` – Short isolate name/code

**Format:** Tab-separated, header row required

**Example:**
```tsv
sample	species	strain	isolate
Isolate_001	F. graminearum	DAOM_12345	FUS001
Isolate_002	F. graminearum	DAOM_12346	FUS002
Isolate_003	F. cerealis	DAOM_12347	FUS003
Isolate_004	F. cerealis	DAOM_12348	FUS004
Isolate_005	F. proliferatum	DAOM_12349	FUS005
Isolate_006	F. proliferatum	DAOM_12350	FUS006
Isolate_007	F. fujikuroi	DAOM_12351	FUS007
Isolate_008	F. fujikuroi	DAOM_12352	FUS008
Isolate_009	F. subglutinans	DAOM_12353	FUS009
Isolate_010	F. subglutinans	DAOM_12354	FUS010
Isolate_011	F. graminearum	DAOM_12355	FUS011
Isolate_012	F. cerealis	DAOM_12356	FUS012
```

**Rules:**
- Exactly 12 rows (one per isolate) + header
- `sample` column must match filename prefixes:
  - `genomes/Isolate_001.fasta`
  - `annotations/Isolate_001.gbk`
  - `proteomes/Isolate_001.faa`
  - `growth_rate_heat_cold.csv` entry: `Isolate_001`
- `species` used for grouping in figures (must be consistent)
- `isolate` used for labels in Fig 4

---

## Complete Directory Structure

```
/90daydata/silage_microbiome/max.chi/MSA_2026/conference_figs/00_input/
├── barlist.tsv
├── genomes/
│   ├── Isolate_001.fasta
│   ├── Isolate_002.fasta
│   └── ... (12 total)
├── annotations/
│   ├── Isolate_001.gbk
│   ├── Isolate_002.gbk
│   └── ... (12 total)
├── proteomes/
│   ├── Isolate_001.faa
│   ├── Isolate_002.faa
│   └── ... (12 total)
├── effectors/
│   ├── Isolate_001_effectors.fasta
│   ├── Isolate_002_effectors.fasta
│   └── ... (12 total)
├── growth_rate_heat_cold.csv
├── growth_rate_optimum.csv
└── barley_pathogenicity.csv
```

---

## Data Validation Checklist

Before running the pipeline:

- [ ] `barlist.tsv` has exactly 12 data rows (+ header)
- [ ] All 12 `genomes/{SAMPLE}.fasta` files exist
- [ ] All 12 `annotations/{SAMPLE}.gbk` or `.gff3` files exist
- [ ] All 12 `proteomes/{SAMPLE}.faa` files exist
- [ ] All 12 `effectors/{SAMPLE}_effectors.fasta` files exist
- [ ] `growth_rate_heat_cold.csv` has rows for both `heat` and `cold` conditions
- [ ] `growth_rate_optimum.csv` has one or more rows per isolate
- [ ] `barley_pathogenicity.csv` has multiple replicates per isolate
- [ ] All CSV files open correctly in Excel/text editor (no encoding issues)
- [ ] No isolate in CSVs is missing from `barlist.tsv`
- [ ] No spaces in sample names (use underscores: `Isolate_001` not `Isolate 001`)

---

## Common Issues & Solutions

### **"Sample not found in barlist"**
→ Isolate name in CSV doesn't match `sample` column in `barlist.tsv`  
→ Check spelling, capitalization, underscores

### **Empty output TSV files (header only)**
→ Input FASTA/GBK files not found in `00_input/`  
→ Filename doesn't match `barlist.tsv` exactly

### **"no attribute 'loc'"** (Python error)
→ CSV parsing failed (wrong delimiter, encoding, or column names)  
→ Re-save CSVs as UTF-8, comma-separated, with exact column names

### **CAzyme counts are 0 for all isolates**
→ `proteomes/*.faa` files are missing or empty  
→ dbCAN module not loaded (check `module load dbcan`)

### **Effector counts very low or zero**
→ `effectors/*_effectors.fasta` files are missing/empty  
→ Verify effector predictions were run (e.g., SignalP, EffectorP, antiSMASH)

---

## Advanced: Custom Modifications

### **Add additional columns to CSVs**
Scripts ignore extra columns, so you can add:
```csv
sample,condition,temperature,replicate,growth_rate,plate_id,observer_notes
Isolate_001,heat,40,1,2.5,P1,no contamination
```

### **Different virulence metrics**
Script treats last numeric column as virulence. If you have multiple metrics:
```csv
sample,replicate,lesion_area,percent_infection,virulence_metric
Isolate_001,1,45.2,23.1,45.2
```
Use the column you want in `virulence_metric`.

### **Multiple temperature treatments**
Just add more rows to `growth_rate_heat_cold.csv`:
```csv
sample,condition,temperature,replicate,growth_rate
Isolate_001,heat,35,1,2.3
Isolate_001,heat,40,1,2.5
Isolate_001,heat,45,1,2.2
Isolate_001,cold,5,1,0.8
Isolate_001,cold,0,1,0.3
```
Figures will show all temperatures grouped by condition.

---

## Version History

| Date | Change |
|------|--------|
| 2026-07-04 | Initial specification (v1.0) |

---

Good luck preparing your data! 📊
