#!/bin/bash
#SBATCH --job-name=phenotype_parsing
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=8G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/06_phenotype"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"

exec > ${LOG_DIR}/06_phenotype_parsing_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 06: PHENOTYPE DATA PARSING
# ============================================================================
# Processes growth rate and pathogenicity data:
#
# Input CSVs:
#   - growth_rate_heat_cold.csv: long format with heat/cold stress data
#   - growth_rate_optimum.csv: diameter at 7 days optimum temp
#   - barley_pathogenicity.csv: raw pathogenicity assay data
#
# Outputs (for Fig 1-3):
#   - growth_rates_summary.tsv: means, std, SEM per condition
#   - pathogenicity_summary.tsv: virulence scores per isolate
# ============================================================================

echo "=== Phenotype Data Parsing ==="
echo "Input: ${INPUT_DIR}/"
echo "Output: ${OUTPUT_DIR}/"
echo ""

BARLIST="${ANALYSIS_ROOT}/barlist.tsv"

# ========== PARSE GROWTH RATE DATA ==========
echo "Processing growth rate data (heat & cold stress)..."

if [[ ! -f "${INPUT_DIR}/growth_rate_heat_cold.csv" ]]; then
    echo "ERROR: growth_rate_heat_cold.csv not found."
    exit 1
fi

if [[ ! -f "${INPUT_DIR}/growth_rate_optimum.csv" ]]; then
    echo "ERROR: growth_rate_optimum.csv not found."
    exit 1
fi

# Parse long-format heat/cold data
# Expected format: sample, condition (heat/cold), temperature, replicate, growth_rate
# Output: means, std, SEM per isolate-condition

GROWTH_SUMMARY="${OUTPUT_DIR}/growth_rates_summary.tsv"
cat > "$GROWTH_SUMMARY" << 'HEADER'
sample	isolate	species	condition	temperature	mean_growth_rate	std_growth_rate	sem_growth_rate	n_replicates
HEADER

# Group by sample-condition and compute stats
awk -F',' 'NR > 1 {
    sample = $1
    condition = $2  # heat or cold
    temp = $3
    rate = $NF      # Last column assumed to be growth_rate
    
    key = sample ":" condition ":" temp
    data[key] = data[key] " " rate
    
} END {
    for (key in data) {
        split(key, parts, ":")
        sample = parts[1]
        condition = parts[2]
        temp = parts[3]
        
        split(data[key], values)
        
        # Compute mean
        sum = 0
        count = 0
        for (v in values) {
            sum += values[v]
            count++
        }
        mean = sum / count
        
        # Compute std dev
        sum_sq_dev = 0
        for (v in values) {
            sum_sq_dev += (values[v] - mean)^2
        }
        std = sqrt(sum_sq_dev / (count - 1))
        sem = std / sqrt(count)
        
        # Look up isolate/species from barlist
        print sample "\t" "ISOLATE_" sample "\t" "SPECIES" "\t" condition "\t" temp "\t" mean "\t" std "\t" sem "\t" count
    }
}' "${INPUT_DIR}/growth_rate_heat_cold.csv" >> "$GROWTH_SUMMARY"

# Also parse optimum temperature (7-day diameter)
echo ""
echo "Processing optimum temperature growth data..."

# Expected format: sample, diameter_mm (at 7 days, optimum temp)
# Assume single measurement per isolate or multiple replicates

OPTIMUM_SUMMARY="${OUTPUT_DIR}/growth_rates_optimum_summary.tsv"
cat > "$OPTIMUM_SUMMARY" << 'HEADER'
sample	isolate	species	condition	mean_diameter_mm	std_diameter_mm	sem_diameter_mm	n_replicates
HEADER

awk -F',' 'NR > 1 {
    sample = $1
    diameter = $2  # diameter in mm
    
    data[sample] = data[sample] " " diameter
    
} END {
    for (sample in data) {
        split(data[sample], values)
        
        sum = 0
        count = 0
        for (v in values) {
            sum += values[v]
            count++
        }
        mean = sum / count
        
        sum_sq_dev = 0
        for (v in values) {
            sum_sq_dev += (values[v] - mean)^2
        }
        std = (count > 1) ? sqrt(sum_sq_dev / (count - 1)) : 0
        sem = std / sqrt(count)
        
        print sample "\t" "ISOLATE_" sample "\t" "SPECIES" "\t" "optimum" "\t" mean "\t" std "\t" sem "\t" count
    }
}' "${INPUT_DIR}/growth_rate_optimum.csv" >> "$OPTIMUM_SUMMARY"

echo "✓ Growth rate summary (heat/cold): $GROWTH_SUMMARY"
echo "✓ Growth rate summary (optimum): $OPTIMUM_SUMMARY"

# ========== PARSE PATHOGENICITY DATA ==========
echo ""
echo "Processing barley pathogenicity assay data..."

if [[ ! -f "${INPUT_DIR}/barley_pathogenicity.csv" ]]; then
    echo "WARNING: barley_pathogenicity.csv not found. Skipping pathogenicity analysis."
else
    # Expected format: sample, replicate, lesion_area_mm2 (or % infection, etc.)
    # Output: virulence score (mean ± SEM) per isolate
    
    PATHOGENICITY_SUMMARY="${OUTPUT_DIR}/pathogenicity_summary.tsv"
    cat > "$PATHOGENICITY_SUMMARY" << 'HEADER'
sample	isolate	species	virulence_score	std_virulence	sem_virulence	n_replicates	infection_severity
HEADER
    
    awk -F',' 'NR > 1 {
        sample = $1
        virulence = $NF  # Last column assumed to be virulence/lesion measurement
        
        data[sample] = data[sample] " " virulence
        
    } END {
        for (sample in data) {
            split(data[sample], values)
            
            sum = 0
            count = 0
            for (v in values) {
                sum += values[v]
                count++
            }
            mean = sum / count
            
            sum_sq_dev = 0
            for (v in values) {
                sum_sq_dev += (values[v] - mean)^2
            }
            std = (count > 1) ? sqrt(sum_sq_dev / (count - 1)) : 0
            sem = std / sqrt(count)
            
            # Classify severity (arbitrary thresholds; adjust as needed)
            if (mean < 25) severity = "low"
            else if (mean < 50) severity = "moderate"
            else severity = "high"
            
            print sample "\t" "ISOLATE_" sample "\t" "SPECIES" "\t" mean "\t" std "\t" sem "\t" count "\t" severity
        }
    }' "${INPUT_DIR}/barley_pathogenicity.csv" >> "$PATHOGENICITY_SUMMARY"
    
    echo "✓ Pathogenicity summary: $PATHOGENICITY_SUMMARY"
    cat "$PATHOGENICITY_SUMMARY"
fi

# ========== MERGED PHENOTYPE TABLE ==========
echo ""
echo "Creating merged phenotype table (for correlation analysis)..."

MERGED_PHENOTYPE="${OUTPUT_DIR}/merged_phenotypes.tsv"
cat > "$MERGED_PHENOTYPE" << 'HEADER'
sample	isolate	species	heat_growth	cold_growth	optimum_diameter	virulence_score
HEADER

# Join all phenotypes into one table
while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    # Get heat growth (if available)
    HEAT_GROWTH=$(grep "$sample" "$GROWTH_SUMMARY" 2>/dev/null | grep "heat" | head -1 | cut -f6)
    HEAT_GROWTH=${HEAT_GROWTH:-"NA"}
    
    # Get cold growth
    COLD_GROWTH=$(grep "$sample" "$GROWTH_SUMMARY" 2>/dev/null | grep "cold" | head -1 | cut -f6)
    COLD_GROWTH=${COLD_GROWTH:-"NA"}
    
    # Get optimum diameter
    OPT_DIAMETER=$(grep "$sample" "$OPTIMUM_SUMMARY" 2>/dev/null | head -1 | cut -f5)
    OPT_DIAMETER=${OPT_DIAMETER:-"NA"}
    
    # Get virulence score
    VIRULENCE=$(grep "$sample" "$PATHOGENICITY_SUMMARY" 2>/dev/null | head -1 | cut -f4)
    VIRULENCE=${VIRULENCE:-"NA"}
    
    echo -e "${sample}\t${isolate}\t${species}\t${HEAT_GROWTH}\t${COLD_GROWTH}\t${OPT_DIAMETER}\t${VIRULENCE}"
    
done < "$BARLIST" >> "$MERGED_PHENOTYPE"

echo "✓ Merged phenotypes: $MERGED_PHENOTYPE"
cat "$MERGED_PHENOTYPE"

# ========== SUMMARY ==========
echo ""
echo "=== Phenotype Parsing Complete ==="
echo "Outputs:"
echo "  - growth_rates_summary.tsv: heat/cold stress growth data (Fig 1)"
echo "  - growth_rates_optimum_summary.tsv: optimum temperature growth (Fig 2)"
echo "  - pathogenicity_summary.tsv: barley virulence scores (Fig 3)"
echo "  - merged_phenotypes.tsv: all phenotypes in one table"

exit 0
