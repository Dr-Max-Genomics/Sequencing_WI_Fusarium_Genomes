#!/bin/bash
#SBATCH --job-name=synteny_analysis
#SBATCH --time=04:00:00
#SBATCH --cpus-per-task=16
#SBATCH --mem=32G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/03_synteny"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"/{paf,bed,fusions}

exec > ${LOG_DIR}/03_synteny_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 03: LINEAGE-SPECIFIC CHROMOSOMAL FISSIONS (Fig 4c)
# ============================================================================
# Uses minimap2 to detect synteny breaks and chromosomal rearrangements.
# Identifies lineage-specific fissions by comparing genomes within and
# across species complexes.
#
# Outputs:
#   - synteny_pairwise.tsv: per-species-pair alignments (PAF)
#   - fusions_fissions.tsv: detected chromosomal rearrangements
#   - lineage_specific_breakpoints.bed: BED file of rearrangement regions
# ============================================================================

echo "=== Synteny Analysis: Chromosomal Fissions ==="
echo ""

BARLIST="${ANALYSIS_ROOT}/barlist.tsv"

# Load minimap2
module load minimap2 2>/dev/null || echo "minimap2 not found as module. Assuming it's in PATH."

# ========== SELECT REFERENCE GENOMES PER SPECIES ==========
# Pick one representative genome per species complex to reduce computation

echo "Identifying reference genomes per species..."

declare -A SPECIES_REF
while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    
    if [[ -z "${SPECIES_REF[$species]:-}" ]]; then
        SPECIES_REF["$species"]="${sample}"
        echo "  Reference for $species: $sample"
    fi
done < "$BARLIST"

# ========== RUN PAIRWISE ALIGNMENTS (WITHIN & ACROSS SPECIES) ==========
echo ""
echo "Running pairwise minimap2 alignments..."

ALIGNMENT_SUMMARY="${OUTPUT_DIR}/synteny_pairwise.tsv"
cat > "$ALIGNMENT_SUMMARY" << 'HEADER'
query_sample	query_species	ref_sample	ref_species	num_alignments	mean_query_cov	mean_ref_cov	synteny_breaks
HEADER

# Within-species comparisons (detect intraspecific fusions/fissions)
declare -a SPECIES_LIST
declare -a SPECIES_SAMPLES

while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue
    SPECIES_SAMPLES+=("$sample:$species")
done < "$BARLIST"

# Pairwise comparisons (limit to representative + key pairs to save time)
for i in "${!SPECIES_SAMPLES[@]}"; do
    IFS=':' read -r sample1 species1 <<< "${SPECIES_SAMPLES[$i]}"
    
    QUERY_FASTA="${INPUT_DIR}/genomes/${sample1}.fasta"
    if [[ ! -f "$QUERY_FASTA" ]]; then
        continue
    fi
    
    # Compare against all species representatives
    for species_ref in "${!SPECIES_REF[@]}"; do
        sample_ref="${SPECIES_REF[$species_ref]}"
        REF_FASTA="${INPUT_DIR}/genomes/${sample_ref}.fasta"
        
        if [[ ! -f "$REF_FASTA" ]]; then
            continue
        fi
        
        if [[ "$QUERY_FASTA" == "$REF_FASTA" ]]; then
            continue
        fi
        
        echo "  Aligning: $sample1 → $sample_ref"
        
        PAF_OUT="${OUTPUT_DIR}/paf/${sample1}_vs_${sample_ref}.paf"
        
        # Run minimap2 (asm5 for assembly-level precision)
        minimap2 -t 8 -x asm5 "$REF_FASTA" "$QUERY_FASTA" > "$PAF_OUT" 2>/dev/null || true
        
        # Parse PAF output
        if [[ -s "$PAF_OUT" ]]; then
            NUM_ALIGNS=$(wc -l < "$PAF_OUT")
            
            # Calculate coverage stats from PAF
            MEAN_QUERY_COV=$(awk '{sum+=$4; count++} END {printf "%.2f", sum/(count*$2)*100}' "$PAF_OUT" 2>/dev/null || echo "NA")
            MEAN_REF_COV=$(awk '{sum+=$8; count++} END {printf "%.2f", sum/(count*$6)*100}' "$PAF_OUT" 2>/dev/null || echo "NA")
            
            # Count synteny breaks: consecutive alignments with gap > 10kb or orientation change
            SYNTENY_BREAKS=$(awk '
            {
                query_end = $4
                ref_end = $8
                strand = $5
                
                if (NR > 1 && query_end - prev_q_end > 10000 || ref_end - prev_r_end > 10000 || strand != prev_strand) {
                    breaks++
                }
                prev_q_end = query_end
                prev_r_end = ref_end
                prev_strand = strand
            }
            END { print breaks+0 }
            ' "$PAF_OUT")
            
            echo -e "${sample1}\t${species1}\t${sample_ref}\t${species_ref}\t${NUM_ALIGNS}\t${MEAN_QUERY_COV}\t${MEAN_REF_COV}\t${SYNTENY_BREAKS}" >> "$ALIGNMENT_SUMMARY"
        fi
    done
done

echo ""
echo "✓ Pairwise alignment summary: $ALIGNMENT_SUMMARY"

# ========== CONVERT PAF TO BED (BREAKPOINT REGIONS) ==========
echo ""
echo "Extracting chromosomal breakpoint regions..."

BREAKPOINT_BED="${OUTPUT_DIR}/fusions/lineage_specific_breakpoints.bed"
cat > "$BREAKPOINT_BED" << 'HEADER'
#chrom	start	end	break_type	query_sample	query_species	ref_sample	ref_species
HEADER

# For each PAF, extract regions where gaps > 10kb (potential fusions/fissions)
for paf_file in ${OUTPUT_DIR}/paf/*.paf; do
    [[ ! -s "$paf_file" ]] && continue
    
    basename_paf=$(basename "$paf_file" .paf)
    IFS='_' read -r sample1 vs sample2 <<< "$basename_paf"
    
    awk -v file="$basename_paf" '
    {
        query_end = $4
        ref_start = $7
        ref_end = $8
        
        if (NR > 1 && (query_end - prev_q_end > 10000 || ref_end - prev_r_end > 10000)) {
            # Fusion/fission region
            gap_size = ref_end - prev_r_end
            print prev_r_end "\t" ref_end "\tfusion_fission\t" file
        }
        prev_q_end = query_end
        prev_r_end = ref_end
    }
    ' "$paf_file" >> "$BREAKPOINT_BED"
done

echo "✓ Breakpoint regions: $BREAKPOINT_BED"

# ========== IDENTIFY LINEAGE-SPECIFIC FISSIONS ==========
echo ""
echo "Identifying lineage-specific fissions..."

LINEAGE_FISSIONS="${OUTPUT_DIR}/fusions/lineage_specific_fissions.tsv"
cat > "$LINEAGE_FISSIONS" << 'HEADER'
species	lineage	fission_count	affected_scaffolds	mean_breakpoint_spacing_kb
HEADER

# Group species by complex and identify high-breakpoint pairs
awk '
NR > 1 && NF > 7 && $8 > 5 {
    species_pair = $2 ":" $4
    count[species_pair]++
    breaks[species_pair] += $8
}
END {
    for (pair in count) {
        if (breaks[pair] > 10) {
            print pair "\t" count[pair] "\t" breaks[pair] / count[pair]
        }
    }
}
' "$ALIGNMENT_SUMMARY" | while read -r pair num_pairs mean_breaks; do
    IFS=':' read -r sp1 sp2 <<< "$pair"
    echo -e "${sp1}_vs_${sp2}\t${sp1}\t${num_pairs}\tMultiple\t${mean_breaks}"
done >> "$LINEAGE_FISSIONS"

echo "✓ Lineage-specific fissions: $LINEAGE_FISSIONS"
cat "$LINEAGE_FISSIONS"

# ========== SUMMARY ==========
echo ""
echo "=== Synteny Analysis Complete ==="
echo "Outputs:"
echo "  - paf/: raw minimap2 alignments"
echo "  - synteny_pairwise.tsv: pairwise comparison stats"
echo "  - fusions/lineage_specific_breakpoints.bed: breakpoint regions"
echo "  - fusions/lineage_specific_fissions.tsv: summary of lineage-specific events"

exit 0
