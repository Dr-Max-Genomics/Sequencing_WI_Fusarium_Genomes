#!/bin/bash
#SBATCH --job-name=genome_stats
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=8G
#SBATCH --output=/dev/null

set -euo pipefail

export PROJECT_ROOT="/90daydata/silage_microbiome/max.chi/MSA_2026"
export ANALYSIS_ROOT="${PROJECT_ROOT}/conference_figs"
export INPUT_DIR="${ANALYSIS_ROOT}/00_input"
export OUTPUT_DIR="${ANALYSIS_ROOT}/01_genome_stats"
export LOG_DIR="${ANALYSIS_ROOT}/logs"

mkdir -p "${OUTPUT_DIR}"

exec > ${LOG_DIR}/01_genome_stats_${SLURM_JOB_ID}.log 2>&1

# ============================================================================
# SCRIPT 01: STRUCTURAL VARIATION OVERVIEW
# ============================================================================
# Extracts genome-level metrics for all 12 isolates:
#   - Genome size (bp)
#   - GC content (%)
#   - Number of scaffolds/contigs
#   - N50, L50
#   - Repeat content (if GFF has repeat features)
#
# Output: genome_stats_summary.tsv (used for Fig 4a overview)
# ============================================================================

echo "=== Genome Stats: Structural Variation Overview ==="
echo "Input: ${INPUT_DIR}/genomes/"
echo "Output: ${OUTPUT_DIR}/"
echo ""

# Source barlist.tsv to get sample names
BARLIST="${ANALYSIS_ROOT}/barlist.tsv"
if [[ ! -f "$BARLIST" ]]; then
    echo "ERROR: barlist.tsv not found. Run 00_setup.sh first."
    exit 1
fi

# Initialize output header
cat > "${OUTPUT_DIR}/genome_stats_summary.tsv" << 'HEADER'
sample	isolate	species	genome_size_bp	gc_percent	num_scaffolds	n50_bp	repeat_percent
HEADER

# Process each isolate
while IFS=$'\t' read -r sample species strain isolate; do
    [[ "$sample" == "sample" ]] && continue  # Skip header
    
    GENOME_FASTA="${INPUT_DIR}/genomes/${sample}.fasta"
    GFF_FILE="${INPUT_DIR}/annotations/${sample}.gff3"
    
    if [[ ! -f "$GENOME_FASTA" ]]; then
        echo "WARNING: ${GENOME_FASTA} not found. Skipping ${sample}."
        continue
    fi
    
    echo "Processing: $sample ($species)"
    
    # ========== GENOME SIZE & GC CONTENT ==========
    GENOME_SIZE=$(cat "$GENOME_FASTA" | grep -v "^>" | wc -c | tr -d ' ')
    
    # Count A, T, G, C
    A_COUNT=$(cat "$GENOME_FASTA" | grep -v "^>" | tr -cd 'A' | wc -c)
    T_COUNT=$(cat "$GENOME_FASTA" | grep -v "^>" | tr -cd 'T' | wc -c)
    G_COUNT=$(cat "$GENOME_FASTA" | grep -v "^>" | tr -cd 'G' | wc -c)
    C_COUNT=$(cat "$GENOME_FASTA" | grep -v "^>" | tr -cd 'C' | wc -c)
    
    TOTAL_ATGC=$((A_COUNT + T_COUNT + G_COUNT + C_COUNT))
    if [[ $TOTAL_ATGC -gt 0 ]]; then
        GC_CONTENT=$(awk "BEGIN {printf \"%.2f\", (($G_COUNT + $C_COUNT) / $TOTAL_ATGC) * 100}")
    else
        GC_CONTENT="NA"
    fi
    
    # ========== SCAFFOLD COUNT & N50 ==========
    NUM_SCAFFOLDS=$(grep -c "^>" "$GENOME_FASTA" || echo "0")
    
    # Calculate N50 using awk
    N50=$(awk '
    /^>/ { if (seq_len > 0) lengths[++n] = seq_len; seq_len = 0; next }
    { seq_len += length($0) }
    END {
        if (seq_len > 0) lengths[++n] = seq_len
        for (i = n; i >= 1; i--) {
            total += lengths[i]
            if (total >= total_genome_len / 2) {
                print lengths[i]
                exit
            }
        }
    }
    ' TOTAL_GENOME_LEN="$TOTAL_ATGC" "$GENOME_FASTA")
    
    N50=${N50:-"NA"}
    
    # ========== REPEAT CONTENT (if GFF available) ==========
    REPEAT_PERCENT="NA"
    if [[ -f "$GFF_FILE" ]]; then
        REPEAT_BP=$(awk '$3 ~ /repeat|transposon/ {sum += ($5 - $4 + 1)} END {print sum+0}' "$GFF_FILE")
        if [[ $TOTAL_ATGC -gt 0 ]]; then
            REPEAT_PERCENT=$(awk "BEGIN {printf \"%.2f\", ($REPEAT_BP / $TOTAL_ATGC) * 100}")
        fi
    fi
    
    # ========== WRITE OUTPUT ==========
    echo -e "${sample}\t${isolate}\t${species}\t${GENOME_SIZE}\t${GC_CONTENT}\t${NUM_SCAFFOLDS}\t${N50}\t${REPEAT_PERCENT}" >> "${OUTPUT_DIR}/genome_stats_summary.tsv"
    
done < "$BARLIST"

echo ""
echo "=== Summary Statistics ==="
cat "${OUTPUT_DIR}/genome_stats_summary.tsv"
echo ""
echo "✓ Genome stats written to: ${OUTPUT_DIR}/genome_stats_summary.tsv"

exit 0
