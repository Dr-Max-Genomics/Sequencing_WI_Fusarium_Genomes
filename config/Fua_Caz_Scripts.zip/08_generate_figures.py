#!/usr/bin/env python3
"""
CONFERENCE FIGURES PIPELINE: Publication-Ready Figure Generation

Generates 5 figure groups:
  1. Heat Stress Growth
  2. Cold Stress Growth  
  3. Optimum Temperature Growth
  4. Barley Pathogenicity
  5. Genome Analyses (4a-4d):
     4a. Structural Variation Overview
     4b. Macro-structural & Accessory Gene Variation
     4c. Lineage-specific Chromosomal Fissions
     4d. Effector Gene Expansions
  6. CAzyme Profiles & Virulence Correlation

Usage:
  python3 08_generate_figures.py /path/to/analysis_root

Output: PNG/PDF files in 08_figures/
"""

import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# Set style
sns.set_style("whitegrid")
sns.set_palette("husl")
plt.rcParams['figure.dpi'] = 300
plt.rcParams['font.size'] = 10
plt.rcParams['font.family'] = 'sans-serif'

def load_data(analysis_root):
    """Load all analysis outputs"""
    data = {}
    
    # Load growth rate data
    try:
        data['growth_heat_cold'] = pd.read_csv(
            f"{analysis_root}/06_phenotype/growth_rates_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: growth_rates_summary.tsv not found")
    
    try:
        data['growth_optimum'] = pd.read_csv(
            f"{analysis_root}/06_phenotype/growth_rates_optimum_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: growth_rates_optimum_summary.tsv not found")
    
    # Load pathogenicity data
    try:
        data['pathogenicity'] = pd.read_csv(
            f"{analysis_root}/06_phenotype/pathogenicity_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: pathogenicity_summary.tsv not found")
    
    # Load genome stats
    try:
        data['genome_stats'] = pd.read_csv(
            f"{analysis_root}/01_genome_stats/genome_stats_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: genome_stats_summary.tsv not found")
    
    # Load accessory genome data
    try:
        data['accessory_summary'] = pd.read_csv(
            f"{analysis_root}/02_accessory_genome/accessory_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: accessory_summary.tsv not found")
    
    # Load synteny data
    try:
        data['synteny_pairwise'] = pd.read_csv(
            f"{analysis_root}/03_synteny/synteny_pairwise.tsv",
            sep='\t'
        )
    except:
        print("WARNING: synteny_pairwise.tsv not found")
    
    # Load effector data
    try:
        data['effector_counts'] = pd.read_csv(
            f"{analysis_root}/04_effector_analysis/effector_counts.tsv",
            sep='\t'
        )
    except:
        print("WARNING: effector_counts.tsv not found")
    
    try:
        data['effector_expansion'] = pd.read_csv(
            f"{analysis_root}/04_effector_analysis/effector_expansion_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: effector_expansion_summary.tsv not found")
    
    # Load CAzyme data
    try:
        data['cazyme_summary'] = pd.read_csv(
            f"{analysis_root}/05_cazyme/cazyme_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: cazyme_summary.tsv not found")
    
    # Load correlation data
    try:
        data['correlation_summary'] = pd.read_csv(
            f"{analysis_root}/07_correlation/correlation_summary.tsv",
            sep='\t'
        )
    except:
        print("WARNING: correlation_summary.tsv not found")
    
    try:
        data['correlation_data'] = pd.read_csv(
            f"{analysis_root}/07_correlation/correlation_data.tsv",
            sep='\t'
        )
    except:
        print("WARNING: correlation_data.tsv not found")
    
    return data

def figure_1_heat_stress(data, output_dir):
    """Fig 1: Heat Stress Growth"""
    if 'growth_heat_cold' not in data:
        print("Skipping Fig 1: heat stress data not available")
        return
    
    df = data['growth_heat_cold']
    heat_data = df[df['condition'] == 'heat']
    
    if heat_data.empty:
        print("Skipping Fig 1: no heat stress data")
        return
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Bar plot with error bars
    species_order = sorted(heat_data['species'].unique())
    
    sns.barplot(
        data=heat_data,
        x='species',
        y='mean_growth_rate',
        order=species_order,
        ax=ax,
        errorbar='sd'
    )
    
    ax.set_xlabel('Fusarium Species', fontsize=12, fontweight='bold')
    ax.set_ylabel('Growth Rate (mm/day)', fontsize=12, fontweight='bold')
    ax.set_title('Heat Stress (Growth Rate)', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    fig.savefig(f"{output_dir}/Fig1_Heat_Stress.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig1_Heat_Stress.png")
    plt.close()

def figure_2_cold_stress(data, output_dir):
    """Fig 2: Cold Stress Growth"""
    if 'growth_heat_cold' not in data:
        return
    
    df = data['growth_heat_cold']
    cold_data = df[df['condition'] == 'cold']
    
    if cold_data.empty:
        print("Skipping Fig 2: no cold stress data")
        return
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    species_order = sorted(cold_data['species'].unique())
    
    sns.barplot(
        data=cold_data,
        x='species',
        y='mean_growth_rate',
        order=species_order,
        ax=ax,
        errorbar='sd'
    )
    
    ax.set_xlabel('Fusarium Species', fontsize=12, fontweight='bold')
    ax.set_ylabel('Growth Rate (mm/day)', fontsize=12, fontweight='bold')
    ax.set_title('Cold Stress (Growth Rate)', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    fig.savefig(f"{output_dir}/Fig2_Cold_Stress.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig2_Cold_Stress.png")
    plt.close()

def figure_3_optimum(data, output_dir):
    """Fig 3: Optimum Temperature Growth"""
    if 'growth_optimum' not in data:
        return
    
    df = data['growth_optimum']
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    species_order = sorted(df['species'].unique())
    
    sns.barplot(
        data=df,
        x='species',
        y='mean_diameter_mm',
        order=species_order,
        ax=ax,
        errorbar='sd'
    )
    
    ax.set_xlabel('Fusarium Species', fontsize=12, fontweight='bold')
    ax.set_ylabel('Colony Diameter (mm)', fontsize=12, fontweight='bold')
    ax.set_title('Optimum Temperature (7-day Colony Diameter)', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    fig.savefig(f"{output_dir}/Fig3_Optimum_Growth.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig3_Optimum_Growth.png")
    plt.close()

def figure_4_barley_pathogenicity(data, output_dir):
    """Fig 4: Barley Seedling Pathogenicity"""
    if 'pathogenicity' not in data:
        return
    
    df = data['pathogenicity']
    
    fig, ax = plt.subplots(figsize=(11, 6))
    
    # Sort by virulence score
    df_sorted = df.sort_values('virulence_score', ascending=False)
    
    # Color by severity
    colors = df_sorted['infection_severity'].map({
        'high': '#d62728',
        'moderate': '#ff7f0e',
        'low': '#2ca02c'
    })
    
    ax.bar(range(len(df_sorted)), df_sorted['virulence_score'], 
           color=colors, edgecolor='black', linewidth=1)
    
    ax.errorbar(range(len(df_sorted)), df_sorted['virulence_score'],
                yerr=df_sorted['sem_virulence'],
                fmt='none', color='black', capsize=3, alpha=0.5)
    
    ax.set_xticks(range(len(df_sorted)))
    ax.set_xticklabels(df_sorted['isolate'], rotation=45, ha='right')
    ax.set_xlabel('Isolate', fontsize=12, fontweight='bold')
    ax.set_ylabel('Virulence Score', fontsize=12, fontweight='bold')
    ax.set_title('Barley Seedling Pathogenicity (Virulence)', fontsize=14, fontweight='bold')
    
    # Add legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#d62728', edgecolor='black', label='High'),
        Patch(facecolor='#ff7f0e', edgecolor='black', label='Moderate'),
        Patch(facecolor='#2ca02c', edgecolor='black', label='Low')
    ]
    ax.legend(handles=legend_elements, title='Severity', loc='upper right')
    
    plt.tight_layout()
    fig.savefig(f"{output_dir}/Fig4_Barley_Pathogenicity.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig4_Barley_Pathogenicity.png")
    plt.close()

def figure_4a_structural_variation(data, output_dir):
    """Fig 4a: Structural Variation Overview (Genome Stats)"""
    if 'genome_stats' not in data:
        return
    
    df = data['genome_stats']
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # Genome size by species
    species_order = sorted(df['species'].unique())
    
    ax = axes[0, 0]
    sns.barplot(data=df, x='species', y='genome_size_bp', order=species_order, ax=ax)
    ax.set_ylabel('Genome Size (bp)', fontweight='bold')
    ax.set_xlabel('')
    ax.set_title('Genome Size', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # GC Content
    ax = axes[0, 1]
    sns.scatterplot(data=df, x='species', y='gc_percent', s=100, ax=ax, hue='species', legend=False)
    ax.set_ylabel('GC Content (%)', fontweight='bold')
    ax.set_xlabel('')
    ax.set_title('GC Content', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Number of scaffolds
    ax = axes[1, 0]
    sns.barplot(data=df, x='species', y='num_scaffolds', order=species_order, ax=ax)
    ax.set_ylabel('Number of Scaffolds', fontweight='bold')
    ax.set_xlabel('Species', fontweight='bold')
    ax.set_title('Genomic Fragmentation', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # N50
    ax = axes[1, 1]
    df_n50 = df[df['n50_bp'] != 'NA'].copy()
    if not df_n50.empty:
        df_n50['n50_bp'] = pd.to_numeric(df_n50['n50_bp'], errors='coerce')
        sns.barplot(data=df_n50, x='species', y='n50_bp', order=species_order, ax=ax)
    ax.set_ylabel('N50 (bp)', fontweight='bold')
    ax.set_xlabel('Species', fontweight='bold')
    ax.set_title('N50 Value', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    plt.suptitle('Structural Variation Overview', fontsize=14, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/Fig4a_Structural_Variation.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig4a_Structural_Variation.png")
    plt.close()

def figure_4b_accessory_genes(data, output_dir):
    """Fig 4b: Macro-structural & Accessory Gene Variation"""
    if 'accessory_summary' not in data:
        return
    
    df = data['accessory_summary']
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Core vs accessory genes
    ax = axes[0]
    df_melted = df[['sample', 'core_genes', 'accessory_genes']].set_index('sample').stack().reset_index()
    df_melted.columns = ['sample', 'gene_type', 'count']
    
    sns.barplot(data=df_melted, x='sample', y='count', hue='gene_type', ax=ax)
    ax.set_xlabel('Isolate', fontweight='bold')
    ax.set_ylabel('Number of Genes', fontweight='bold')
    ax.set_title('Core vs Accessory Genes', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Gene count variation
    ax = axes[1]
    ax.scatter(df['sample'], df['total_genes'], s=150, alpha=0.6, label='Total')
    ax.scatter(df['sample'], df['core_genes'], s=100, alpha=0.6, label='Core')
    ax.scatter(df['sample'], df['accessory_genes'], s=100, alpha=0.6, label='Accessory')
    ax.set_xlabel('Isolate', fontweight='bold')
    ax.set_ylabel('Number of Genes', fontweight='bold')
    ax.set_title('Gene Count Distribution', fontweight='bold')
    ax.legend()
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    plt.suptitle('Macro-structural & Accessory Gene Variation', fontsize=14, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/Fig4b_Accessory_Genes.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig4b_Accessory_Genes.png")
    plt.close()

def figure_4c_lineage_fissions(data, output_dir):
    """Fig 4c: Lineage-specific Chromosomal Fissions (Synteny)"""
    if 'synteny_pairwise' not in data:
        return
    
    df = data['synteny_pairwise']
    
    # Focus on within-species vs between-species comparisons
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Synteny breaks by species pair
    ax = axes[0]
    df_top = df.nlargest(12, 'synteny_breaks')
    species_pairs = df_top['query_species'] + ' vs ' + df_top['ref_species']
    
    sns.barplot(data=df_top, x=range(len(df_top)), y='synteny_breaks', ax=ax, palette='Set2')
    ax.set_xticklabels(species_pairs, rotation=45, ha='right')
    ax.set_xlabel('Species Pair', fontweight='bold')
    ax.set_ylabel('Number of Synteny Breaks', fontweight='bold')
    ax.set_title('Chromosomal Rearrangements (Top 12)', fontweight='bold')
    
    # Alignment coverage vs breaks
    ax = axes[1]
    ax.scatter(df['mean_query_cov'], df['synteny_breaks'], 
               s=100, alpha=0.6, c=df['num_alignments'], cmap='viridis')
    ax.set_xlabel('Query Coverage (%)', fontweight='bold')
    ax.set_ylabel('Synteny Breaks', fontweight='bold')
    ax.set_title('Coverage vs Rearrangements', fontweight='bold')
    cbar = plt.colorbar(ax.collections[0], ax=ax)
    cbar.set_label('Num Alignments', fontweight='bold')
    
    plt.suptitle('Lineage-specific Chromosomal Fissions', fontsize=14, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/Fig4c_Chromosomal_Fissions.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig4c_Chromosomal_Fissions.png")
    plt.close()

def figure_4d_effector_expansions(data, output_dir):
    """Fig 4d: Effector Gene Expansions"""
    if 'effector_counts' not in data:
        return
    
    df = data['effector_counts']
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    species_order = sorted(df['species'].unique())
    
    # Total effectors per isolate
    ax = axes[0, 0]
    df_sorted = df.sort_values('num_effectors', ascending=False)
    sns.barplot(data=df_sorted, x='sample', y='num_effectors', ax=ax, palette='husl')
    ax.set_ylabel('Number of Effectors', fontweight='bold')
    ax.set_xlabel('')
    ax.set_title('Effector Count per Isolate', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Effectors per Mb
    ax = axes[0, 1]
    df_sorted2 = df[df['proteins_per_mb'] != 'NA'].copy()
    df_sorted2['proteins_per_mb'] = pd.to_numeric(df_sorted2['proteins_per_mb'], errors='coerce')
    df_sorted2 = df_sorted2.sort_values('proteins_per_mb', ascending=False)
    sns.barplot(data=df_sorted2, x='sample', y='proteins_per_mb', ax=ax, palette='Set2')
    ax.set_ylabel('Effectors per Mb', fontweight='bold')
    ax.set_xlabel('')
    ax.set_title('Effector Density', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Expansion by species
    if 'effector_expansion' in data:
        ax = axes[1, 0]
        exp_df = data['effector_expansion']
        sns.barplot(data=exp_df, x='species', y='expansion_index', ax=ax, palette='Spectral')
        ax.set_ylabel('Expansion Index (Max/Min)', fontweight='bold')
        ax.set_xlabel('Species', fontweight='bold')
        ax.set_title('Intraspecific Effector Expansion', fontweight='bold')
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Boxplot by species
    ax = axes[1, 1]
    sns.boxplot(data=df, x='species', y='num_effectors', ax=ax)
    ax.set_ylabel('Number of Effectors', fontweight='bold')
    ax.set_xlabel('Species', fontweight='bold')
    ax.set_title('Effector Distribution by Species', fontweight='bold')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    plt.suptitle('Effector Gene Expansions', fontsize=14, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/Fig4d_Effector_Expansions.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig4d_Effector_Expansions.png")
    plt.close()

def figure_5_cazyme_virulence(data, output_dir):
    """Fig 5: CAzyme Profiles & Correlation with Virulence"""
    if 'cazyme_summary' not in data or 'correlation_data' not in data:
        return
    
    cazyme_df = data['cazyme_summary']
    corr_df = data['correlation_data']
    
    fig = plt.figure(figsize=(14, 10))
    gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3)
    
    # CAzyme family distribution
    ax1 = fig.add_subplot(gs[0, :])
    family_counts = {'GH': cazyme_df['gh_count'].sum(),
                     'GT': cazyme_df['gt_count'].sum(),
                     'PL': cazyme_df['pl_count'].sum(),
                     'CE': cazyme_df['ce_count'].sum()}
    
    ax1.bar(family_counts.keys(), family_counts.values(), color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'])
    ax1.set_ylabel('Total Count', fontweight='bold')
    ax1.set_title('CAzyme Family Distribution Across All Isolates', fontweight='bold')
    
    # CAzyme count per isolate
    ax2 = fig.add_subplot(gs[1, 0])
    cazyme_sorted = cazyme_df.sort_values('total_cazymes', ascending=False)
    sns.barplot(data=cazyme_sorted, x='sample', y='total_cazymes', ax=ax2, palette='viridis')
    ax2.set_ylabel('Total CAzymes', fontweight='bold')
    ax2.set_xlabel('')
    ax2.set_title('CAzyme Counts per Isolate', fontweight='bold')
    plt.setp(ax2.get_xticklabels(), rotation=45, ha='right')
    
    # CAzyme percent
    ax3 = fig.add_subplot(gs[1, 1])
    cazyme_pct = cazyme_df[cazyme_df['cazyme_percent'] != 'NA'].copy()
    if not cazyme_pct.empty:
        cazyme_pct['cazyme_percent'] = pd.to_numeric(cazyme_pct['cazyme_percent'], errors='coerce')
        sns.boxplot(data=cazyme_pct, x='species', y='cazyme_percent', ax=ax3)
    ax3.set_ylabel('CAzyme % of Proteome', fontweight='bold')
    ax3.set_xlabel('Species', fontweight='bold')
    ax3.set_title('CAzyme Percentage by Species', fontweight='bold')
    plt.setp(ax3.get_xticklabels(), rotation=45, ha='right')
    
    # Correlation scatter plots
    if 'virulence_score' in corr_df.columns:
        ax4 = fig.add_subplot(gs[2, 0])
        valid_data = corr_df.dropna(subset=['total_cazymes', 'virulence_score'])
        if not valid_data.empty:
            ax4.scatter(valid_data['total_cazymes'], valid_data['virulence_score'], s=100, alpha=0.6)
            # Add trend line
            z = np.polyfit(valid_data['total_cazymes'], valid_data['virulence_score'], 1)
            p = np.poly1d(z)
            ax4.plot(sorted(valid_data['total_cazymes']), 
                    p(sorted(valid_data['total_cazymes'])), 
                    "r--", alpha=0.8, linewidth=2)
            ax4.set_xlabel('Total CAzymes', fontweight='bold')
            ax4.set_ylabel('Virulence Score', fontweight='bold')
            ax4.set_title('CAzymes vs Virulence', fontweight='bold')
        
        # GH count vs virulence
        ax5 = fig.add_subplot(gs[2, 1])
        valid_data2 = corr_df.dropna(subset=['gh_count', 'virulence_score'])
        if not valid_data2.empty:
            ax5.scatter(valid_data2['gh_count'], valid_data2['virulence_score'], s=100, alpha=0.6, color='orange')
            z = np.polyfit(valid_data2['gh_count'], valid_data2['virulence_score'], 1)
            p = np.poly1d(z)
            ax5.plot(sorted(valid_data2['gh_count']), 
                    p(sorted(valid_data2['gh_count'])), 
                    "r--", alpha=0.8, linewidth=2)
            ax5.set_xlabel('GH Count', fontweight='bold')
            ax5.set_ylabel('Virulence Score', fontweight='bold')
            ax5.set_title('GH Enzymes vs Virulence', fontweight='bold')
    
    plt.suptitle('CAzyme Profiles & Correlation with Barley Virulence', fontsize=14, fontweight='bold')
    fig.savefig(f"{output_dir}/Fig5_CAzyme_Virulence.png", dpi=300, bbox_inches='tight')
    print(f"✓ Saved: Fig5_CAzyme_Virulence.png")
    plt.close()

def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <analysis_root>")
        sys.exit(1)
    
    analysis_root = sys.argv[1]
    output_dir = f"{analysis_root}/08_figures"
    
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    print(f"Loading data from: {analysis_root}")
    data = load_data(analysis_root)
    
    print(f"Generating figures in: {output_dir}")
    
    # Generate all figures
    figure_1_heat_stress(data, output_dir)
    figure_2_cold_stress(data, output_dir)
    figure_3_optimum(data, output_dir)
    figure_4_barley_pathogenicity(data, output_dir)
    
    # Genome analyses
    figure_4a_structural_variation(data, output_dir)
    figure_4b_accessory_genes(data, output_dir)
    figure_4c_lineage_fissions(data, output_dir)
    figure_4d_effector_expansions(data, output_dir)
    
    # CAzyme correlations
    figure_5_cazyme_virulence(data, output_dir)
    
    print(f"\n✓ All figures generated in: {output_dir}")

if __name__ == "__main__":
    main()
